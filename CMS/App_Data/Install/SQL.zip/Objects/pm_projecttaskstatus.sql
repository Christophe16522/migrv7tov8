CREATE TABLE [PM_ProjectTaskStatus] (
		[TaskStatusID]               [int] IDENTITY(1, 1) NOT NULL,
		[TaskStatusName]             [nvarchar](200) NOT NULL,
		[TaskStatusDisplayName]      [nvarchar](200) NOT NULL,
		[TaskStatusOrder]            [int] NOT NULL,
		[TaskStatusColor]            [nvarchar](7) NULL,
		[TaskStatusIcon]             [nvarchar](450) NULL,
		[TaskStatusGUID]             [uniqueidentifier] NOT NULL,
		[TaskStatusLastModified]     [datetime2](7) NOT NULL,
		[TaskStatusEnabled]          [bit] NOT NULL,
		[TaskStatusIsNotStarted]     [bit] NOT NULL,
		[TaskStatusIsFinished]       [bit] NOT NULL
) 
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [PK_PM_ProjectTaskStatus]
	PRIMARY KEY
	CLUSTERED
	([TaskStatusID])
	
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusDisplayName]
	DEFAULT (N'') FOR [TaskStatusDisplayName]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusEnabled]
	DEFAULT ((1)) FOR [TaskStatusEnabled]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [TaskStatusGUID]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusIsFinished]
	DEFAULT ((0)) FOR [TaskStatusIsFinished]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusIsNotStarted]
	DEFAULT ((0)) FOR [TaskStatusIsNotStarted]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusLastModified]
	DEFAULT ('11/1/2013 4:48:07 PM') FOR [TaskStatusLastModified]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusName]
	DEFAULT (N'') FOR [TaskStatusName]
ALTER TABLE [PM_ProjectTaskStatus]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskStatus_TaskStatusOrder]
	DEFAULT ((0)) FOR [TaskStatusOrder]

