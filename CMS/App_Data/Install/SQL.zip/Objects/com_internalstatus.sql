CREATE TABLE [COM_InternalStatus] (
		[InternalStatusID]               [int] IDENTITY(1, 1) NOT NULL,
		[InternalStatusName]             [nvarchar](200) NOT NULL,
		[InternalStatusDisplayName]      [nvarchar](200) NOT NULL,
		[InternalStatusEnabled]          [bit] NOT NULL,
		[InternalStatusGUID]             [uniqueidentifier] NOT NULL,
		[InternalStatusLastModified]     [datetime2](7) NOT NULL,
		[InternalStatusSiteID]           [int] NULL
) 
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [PK_COM_InternalStatus]
	PRIMARY KEY
	NONCLUSTERED
	([InternalStatusID])
	
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [DEFAULT_COM_InternalStatus_InternalStatusDisplayName]
	DEFAULT (N'') FOR [InternalStatusDisplayName]
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [DEFAULT_COM_InternalStatus_InternalStatusEnabled]
	DEFAULT ((1)) FOR [InternalStatusEnabled]
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [DEFAULT_COM_InternalStatus_InternalStatusGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [InternalStatusGUID]
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [DEFAULT_COM_InternalStatus_InternalStatusLastModified]
	DEFAULT ('9/20/2012 2:45:44 PM') FOR [InternalStatusLastModified]
ALTER TABLE [COM_InternalStatus]
	ADD
	CONSTRAINT [DEFAULT_COM_InternalStatus_InternalStatusName]
	DEFAULT (N'') FOR [InternalStatusName]
CREATE CLUSTERED INDEX [IX_COM_InternalStatus_InternalStatusDisplayName_InternalStatusEnabled]
	ON [COM_InternalStatus] ([InternalStatusDisplayName], [InternalStatusEnabled]) 
CREATE NONCLUSTERED INDEX [IX_COM_InternalStatus_InternalStatusSiteID]
	ON [COM_InternalStatus] ([InternalStatusSiteID]) 

ALTER TABLE [COM_InternalStatus]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_InternalStatus_InternalStatusSiteID_CMS_Site]
	FOREIGN KEY ([InternalStatusSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_InternalStatus]
	CHECK CONSTRAINT [FK_COM_InternalStatus_InternalStatusSiteID_CMS_Site]
