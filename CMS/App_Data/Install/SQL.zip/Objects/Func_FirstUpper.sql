CREATE FUNCTION [Func_FirstUpper] (
 @str NVARCHAR(MAX)
)  
RETURNS NVARCHAR(MAX) AS
BEGIN
	DECLARE @strlen AS INT = LEN(@str);
	IF (@strlen > 0)
	BEGIN
		SET @str = UPPER(LEFT(@str, 1)) + RIGHT(@str, @strlen - 1)
	END
	RETURN @str 
END
