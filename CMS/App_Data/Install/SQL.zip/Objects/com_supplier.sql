CREATE TABLE [COM_Supplier] (
		[SupplierID]               [int] IDENTITY(1, 1) NOT NULL,
		[SupplierDisplayName]      [nvarchar](200) NOT NULL,
		[SupplierPhone]            [nvarchar](50) NULL,
		[SupplierEmail]            [nvarchar](200) NULL,
		[SupplierFax]              [nvarchar](50) NULL,
		[SupplierEnabled]          [bit] NOT NULL,
		[SupplierGUID]             [uniqueidentifier] NOT NULL,
		[SupplierLastModified]     [datetime2](7) NOT NULL,
		[SupplierSiteID]           [int] NULL,
		[SupplierName]             [nvarchar](200) NULL
) 
ALTER TABLE [COM_Supplier]
	ADD
	CONSTRAINT [PK_COM_Supplier]
	PRIMARY KEY
	NONCLUSTERED
	([SupplierID])
	
ALTER TABLE [COM_Supplier]
	ADD
	CONSTRAINT [DEFAULT_COM_Supplier_SupplierDisplayName]
	DEFAULT ('') FOR [SupplierDisplayName]
ALTER TABLE [COM_Supplier]
	ADD
	CONSTRAINT [DEFAULT_COM_Supplier_SupplierEnabled]
	DEFAULT ((1)) FOR [SupplierEnabled]
ALTER TABLE [COM_Supplier]
	ADD
	CONSTRAINT [DEFAULT_COM_Supplier_SupplierGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [SupplierGUID]
ALTER TABLE [COM_Supplier]
	ADD
	CONSTRAINT [DEFAULT_COM_Supplier_SupplierLastModified]
	DEFAULT ('9/21/2012 12:34:09 PM') FOR [SupplierLastModified]
CREATE CLUSTERED INDEX [IX_COM_Supplier_SupplierDisplayName_SupplierEnabled]
	ON [COM_Supplier] ([SupplierDisplayName], [SupplierEnabled]) 
CREATE NONCLUSTERED INDEX [IX_COM_Supplier_SupplierSiteID]
	ON [COM_Supplier] ([SupplierSiteID]) 

ALTER TABLE [COM_Supplier]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_Supplier_SupplierSiteID_CMS_Site]
	FOREIGN KEY ([SupplierSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_Supplier]
	CHECK CONSTRAINT [FK_COM_Supplier_SupplierSiteID_CMS_Site]
