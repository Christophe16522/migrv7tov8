CREATE TABLE [COM_OrderAddress] (
		[AddressID]               [int] IDENTITY(1, 1) NOT NULL,
		[AddressLine1]            [nvarchar](100) NOT NULL,
		[AddressLine2]            [nvarchar](100) NULL,
		[AddressCity]             [nvarchar](100) NOT NULL,
		[AddressZip]              [nvarchar](20) NOT NULL,
		[AddressPhone]            [nvarchar](100) NULL,
		[AddressCountryID]        [int] NOT NULL,
		[AddressStateID]          [int] NULL,
		[AddressPersonalName]     [nvarchar](200) NOT NULL,
		[AddressGUID]             [uniqueidentifier] NULL,
		[AddressLastModified]     [datetime2](7) NOT NULL
) 
ALTER TABLE [COM_OrderAddress]
	ADD
	CONSTRAINT [PK_COM_OrderAddress]
	PRIMARY KEY
	CLUSTERED
	([AddressID])
	
CREATE NONCLUSTERED INDEX [IX_COM_OrderAddress_AddressCountryID]
	ON [COM_OrderAddress] ([AddressCountryID]) 
CREATE NONCLUSTERED INDEX [IX_COM_OrderAddress_AddressStateID]
	ON [COM_OrderAddress] ([AddressStateID]) 

ALTER TABLE [COM_OrderAddress]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_OrderAddress_AddressCountryID_CMS_Country]
	FOREIGN KEY ([AddressCountryID]) REFERENCES [CMS_Country] ([CountryID])
ALTER TABLE [COM_OrderAddress]
	CHECK CONSTRAINT [FK_COM_OrderAddress_AddressCountryID_CMS_Country]
ALTER TABLE [COM_OrderAddress]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_OrderAddress_AddressStateID_CMS_State]
	FOREIGN KEY ([AddressStateID]) REFERENCES [CMS_State] ([StateID])
ALTER TABLE [COM_OrderAddress]
	CHECK CONSTRAINT [FK_COM_OrderAddress_AddressStateID_CMS_State]
