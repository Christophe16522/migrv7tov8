CREATE TABLE [COM_ExchangeTable] (
		[ExchangeTableID]                         [int] IDENTITY(1, 1) NOT NULL,
		[ExchangeTableDisplayName]                [nvarchar](200) NOT NULL,
		[ExchangeTableValidFrom]                  [datetime2](7) NULL,
		[ExchangeTableValidTo]                    [datetime2](7) NULL,
		[ExchangeTableGUID]                       [uniqueidentifier] NOT NULL,
		[ExchangeTableLastModified]               [datetime2](7) NOT NULL,
		[ExchangeTableSiteID]                     [int] NULL,
		[ExchangeTableRateFromGlobalCurrency]     [float] NULL
) 
ALTER TABLE [COM_ExchangeTable]
	ADD
	CONSTRAINT [PK_COM_ExchangeTable]
	PRIMARY KEY
	NONCLUSTERED
	([ExchangeTableID])
	
ALTER TABLE [COM_ExchangeTable]
	ADD
	CONSTRAINT [DEFAULT_COM_ExchangeTable_ExchangeTableDisplayName]
	DEFAULT (N'') FOR [ExchangeTableDisplayName]
CREATE NONCLUSTERED INDEX [IX_COM_ExchangeTable_ExchangeTableSiteID]
	ON [COM_ExchangeTable] ([ExchangeTableSiteID]) 
CREATE CLUSTERED INDEX [IX_COM_ExchangeTable_ExchangeTableValidFrom_ExchangeTableValidTo]
	ON [COM_ExchangeTable] ([ExchangeTableValidFrom] DESC, [ExchangeTableValidTo] DESC) 

ALTER TABLE [COM_ExchangeTable]
	WITH CHECK
	ADD CONSTRAINT [FK_COM_ExchangeTable_ExchangeTableSiteID_CMS_Site]
	FOREIGN KEY ([ExchangeTableSiteID]) REFERENCES [CMS_Site] ([SiteID])
ALTER TABLE [COM_ExchangeTable]
	CHECK CONSTRAINT [FK_COM_ExchangeTable_ExchangeTableSiteID_CMS_Site]
