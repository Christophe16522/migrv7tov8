CREATE TABLE [Reporting_Report] (
		[ReportID]                     [int] IDENTITY(1, 1) NOT NULL,
		[ReportName]                   [nvarchar](200) NOT NULL,
		[ReportDisplayName]            [nvarchar](440) NOT NULL,
		[ReportLayout]                 [nvarchar](max) NULL,
		[ReportParameters]             [nvarchar](max) NULL,
		[ReportCategoryID]             [int] NOT NULL,
		[ReportAccess]                 [int] NOT NULL,
		[ReportGUID]                   [uniqueidentifier] NOT NULL,
		[ReportLastModified]           [datetime2](7) NOT NULL,
		[ReportEnableSubscription]     [bit] NULL,
		[ReportConnectionString]       [nvarchar](100) NULL
)  
ALTER TABLE [Reporting_Report]
	ADD
	CONSTRAINT [PK_Reporting_Report]
	PRIMARY KEY
	NONCLUSTERED
	([ReportID])
	
ALTER TABLE [Reporting_Report]
	ADD
	CONSTRAINT [DEFAULT_Reporting_Report_ReportAccess]
	DEFAULT ((1)) FOR [ReportAccess]
ALTER TABLE [Reporting_Report]
	ADD
	CONSTRAINT [DEFAULT_Reporting_Report_ReportDisplayName]
	DEFAULT ('') FOR [ReportDisplayName]
ALTER TABLE [Reporting_Report]
	ADD
	CONSTRAINT [DEFAULT_Reporting_Report_ReportEnableSubscription]
	DEFAULT ((0)) FOR [ReportEnableSubscription]
ALTER TABLE [Reporting_Report]
	ADD
	CONSTRAINT [DEFAULT_Reporting_Report_ReportName]
	DEFAULT ('') FOR [ReportName]
CREATE NONCLUSTERED INDEX [IX_Reporting_Report_ReportCategoryID]
	ON [Reporting_Report] ([ReportCategoryID]) 
CREATE CLUSTERED INDEX [IX_Reporting_Report_ReportCategoryID_ReportDisplayName]
	ON [Reporting_Report] ([ReportDisplayName], [ReportCategoryID]) 
CREATE NONCLUSTERED INDEX [IX_Reporting_Report_ReportGUID_ReportName]
	ON [Reporting_Report] ([ReportGUID], [ReportName]) 
CREATE UNIQUE NONCLUSTERED INDEX [IX_Reporting_Report_ReportName]
	ON [Reporting_Report] ([ReportName]) 

ALTER TABLE [Reporting_Report]
	WITH NOCHECK
	ADD CONSTRAINT [FK_Reporting_Report_ReportCategory_Reporting_ReportCategory]
	FOREIGN KEY ([ReportCategoryID]) REFERENCES [Reporting_ReportCategory] ([CategoryID])
ALTER TABLE [Reporting_Report]
	CHECK CONSTRAINT [FK_Reporting_Report_ReportCategory_Reporting_ReportCategory]
ALTER TABLE [Reporting_Report]
	WITH NOCHECK
	ADD CONSTRAINT [FK_Reporting_Report_ReportCategoryID_Reporting_ReportCategory]
	FOREIGN KEY ([ReportCategoryID]) REFERENCES [Reporting_ReportCategory] ([CategoryID])
ALTER TABLE [Reporting_Report]
	CHECK CONSTRAINT [FK_Reporting_Report_ReportCategoryID_Reporting_ReportCategory]
