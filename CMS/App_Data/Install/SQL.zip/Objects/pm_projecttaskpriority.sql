CREATE TABLE [PM_ProjectTaskPriority] (
		[TaskPriorityID]               [int] IDENTITY(1, 1) NOT NULL,
		[TaskPriorityName]             [nvarchar](200) NOT NULL,
		[TaskPriorityDisplayName]      [nvarchar](200) NOT NULL,
		[TaskPriorityOrder]            [int] NULL,
		[TaskPriorityGUID]             [uniqueidentifier] NOT NULL,
		[TaskPriorityLastModified]     [datetime2](7) NOT NULL,
		[TaskPriorityEnabled]          [bit] NOT NULL,
		[TaskPriorityDefault]          [bit] NOT NULL
) 
ALTER TABLE [PM_ProjectTaskPriority]
	ADD
	CONSTRAINT [PK_PM_ProjectTaskPriority]
	PRIMARY KEY
	CLUSTERED
	([TaskPriorityID])
	
ALTER TABLE [PM_ProjectTaskPriority]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskPriority_TaskPriorityDisplayName]
	DEFAULT (N'') FOR [TaskPriorityDisplayName]
ALTER TABLE [PM_ProjectTaskPriority]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskPriority_TaskPriorityGUID]
	DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [TaskPriorityGUID]
ALTER TABLE [PM_ProjectTaskPriority]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskPriority_TaskPriorityLastModified]
	DEFAULT ('11/1/2013 3:37:29 PM') FOR [TaskPriorityLastModified]
ALTER TABLE [PM_ProjectTaskPriority]
	ADD
	CONSTRAINT [DEFAULT_PM_ProjectTaskPriority_TaskPriorityName]
	DEFAULT (N'') FOR [TaskPriorityName]

