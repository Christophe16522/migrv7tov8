CREATE PROCEDURE [Proc_Personas_EvaluateContact]
	-- Add the parameters for the stored procedure here
	@ContactId int,
	@SiteId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT TOP 1 [PersonaID] FROM 
	(
		SELECT [PersonaID], 1.0 * [Sum] / [PersonaPointsThreshold] AS [Quotient] FROM
		(
			SELECT [PersonaID], [PersonaPointsThreshold], SUM([Value]) AS [Sum]
			FROM [OM_ScoreContactRule] LEFT JOIN [Personas_Persona] ON [ScoreID] = [PersonaScoreID] 
			WHERE 
				[PersonaSiteId] = @SiteId AND
				[PersonaEnabled] = 1 AND
				[ContactID] = @ContactId AND
				(
					[Expiration] IS NULL OR 
					[Expiration] <= GetDate()
				)
			GROUP BY [PersonaID], [PersonaPointsThreshold]
		) AS [First]
	) AS [Second]
	WHERE [Quotient] >= 1
	ORDER BY [Quotient] DESC
END
