CREATE PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10),
 @GenerateAliases bit
AS
BEGIN
	DECLARE @nodeParentId int;
	DECLARE @parentDocumentCulture nvarchar(10);
	DECLARE @parentUseNamePathForUrlPath bit;
	DECLARE @parentDocumentUrlPath nvarchar(450);
	DECLARE @parentDocumentNamePath nvarchar(1500);
	DECLARE @documentUseNamePathForUrlPath bit;
	DECLARE @updatedChildren int;
	-- Cursor for all parent culture vesions in current level
	DECLARE @parentCursor CURSOR;
	-- Temp table for all parent culture vesions in current level
	DECLARE @parents TABLE (
		NodeParentID int,
		DocumentCulture nvarchar(10)
	);
	-- Get all parent culture versions in current level
	INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined_Regular WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID
	-- Iterate through parent culture versions
	SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
	OPEN @parentCursor
	FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	-- There is parent document to process
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Get best match (culture version) for parent document URL path and name path (including parent link documents)
		SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath 
			FROM (SELECT TOP 1 DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
				FROM View_CMS_Tree_Joined 
					WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
			ORDER BY Priority ASC) TopParentPath;
		-- Document aliases should be generated		
		IF (@GenerateAliases = 1)
		BEGIN
			-- Insert alias for all child documents where original URL path differs from the new one and the alias with same URL path doesn't exist
			INSERT INTO CMS_DocumentAlias (AliasNodeID, AliasCulture, AliasURLPath, AliasExtensions, AliasCampaign, AliasWildcardRule, AliasPriority, AliasGUID, AliasLastModified, AliasSiteID)
				SELECT NodeID AS AliasNodeID, DocumentCulture AS AliasCulture, DocumentURLPath AS AliasURLPath, '' AS AliasExtensions, '' AS AliasCampaign, '' AS AliasWildcardRule, 1 AS AliasPriority, NEWID() AS AliasGUID, GETDATE() AS AliasLastModified, @SiteID AS AliasSiteID
					FROM View_CMS_Tree_Joined 
						-- For all child documents in the same culture
						WHERE NodeParentID = @nodeParentId AND DocumentCulture = @parentDocumentCulture 
						-- URL path is used and differs from the original one
						AND DocumentUrlPath <> (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
						-- There is no alias with the same URL path
						AND NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = DocumentUrlPath AND AliasNodeID = NodeID AND (AliasCulture = DocumentCulture OR ISNULL(AliasCulture, '') = ''))
		END
				
		-- Update name path and URL path for all child documents in parent culture
		UPDATE CMS_Document SET 
			DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, 
			DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND  (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
			-- In the same culture
			WHERE DocumentCulture = @parentDocumentCulture
			-- All child documents
			AND DocumentNodeID IN (SELECT NodeID FROM CMS_Tree WHERE NodeParentID = @nodeParentId) 
		
		-- Store number of updated child documents
		SET @updatedChildren = @@ROWCOUNT
		-- Get next parent
		FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	END
	
	CLOSE @parentCursor;
	DEALLOCATE @parentCursor;
	-- All parents in level processed
	-- There are child documents to process
	IF @updatedChildren <> 0
	BEGIN
		-- Process next level
		SET @NodeLevel = @NodeLevel + 1;
		EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode, @GenerateAliases;															
	END
END
