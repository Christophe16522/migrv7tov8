CREATE PROCEDURE [Proc_Personas_ReevaluateAllContacts]
	@SiteId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   -- Temporary table used for storing contact's persona
	DECLARE @TEMP TABLE
	(
	  [ContactID] int,
	  [PersonaID] int
	)
	INSERT INTO @TEMP
	SELECT [ContactID], [PersonaID] FROM
	(
		-- Order personas for contact by quotient to be able to retrieve the persone with highest quotient
		SELECT [PersonaID], [ContactID], ROW_NUMBER() OVER (PARTITION BY [ContactID] ORDER BY [Quotient] DESC, [PersonaID] ASC) AS [RowNumber] FROM 
		(
			SELECT [PersonaID], [ContactID], 1.0 * [TotalPoints] / [PersonaPointsThreshold] AS [Quotient] FROM
			(
				-- Join contact with counted points for persona rules
				SELECT [PersonaID], [ContactID], [PersonaPointsThreshold], SUM([Value]) AS [TotalPoints]
				FROM [Personas_Persona] 
				LEFT JOIN [OM_ScoreContactRule] ON [ScoreID] = [PersonaScoreID] 
				WHERE [PersonaSiteId] = @SiteId
					AND [PersonaEnabled] = 1
					AND 
					(
						[Expiration] IS NULL OR 
						[Expiration] <= GetDate()
					)
				GROUP BY [PersonaID], [ContactId], [PersonaPointsThreshold]
			) AS [First]
			
		) AS [Second] 
		-- Omit all contacts with not enough points for persona
		where [Quotient] >= 1
	) AS [Third] 
	WHERE [Third].[RowNumber] = 1
	-- Set new persona for contacts from temporary table loaded earlier, if contact is not in temp table it means that he does not belong to any persona and NULL is set to the ContactPersonaID column
	UPDATE [OM_Contact]
	SET [ContactPersonaID] = [@Temp].[PersonaID]
	FROM [OM_Contact]
	LEFT JOIN @TEMP ON [@TEMP].[ContactID] = [OM_Contact].[ContactID]
	WHERE [OM_Contact].[ContactSiteID] = @SiteId AND [OM_Contact].[ContactMergedWithContactID] IS NULL
END
