-- HF-23 - Media libraries - Wrong license feature was checked for Media libraries application
GO
UPDATE [CMS_UIElement] SET [ElementFeature] = NULL WHERE [ElementName] = N'MediaLibrary'
GO

-- HF-33 - Newsletters - Send tab was hidden in some scenarios (e.g. mail-out was scheduled for an issue and resending of issue was disabled)
GO
UPDATE [CMS_UIElement] SET [ElementVisibilityCondition] = N'{%EditedObject.IssueIsABTest || EditedObjectParent.NewsletterEnableResending || (EditedObject.IssueStatus < 2)%}'
WHERE [ElementName] = N'Newsletter.Issue.Send' AND [ElementVisibilityCondition] LIKE N'{\%EditedObjectParent.NewsletterType=="D" || EditedObject.IssueIsABTest || EditedObjectParent.NewsletterEnableResending || (EditedObject.IssueStatus == 0) || (EditedObject.IssueStatus == null)|(user)%(hash)%\%}' escape '\'
GO

-- CM - 131 - Move UI Page templates category to root 
GO
UPDATE CMS_PageTemplateCategory SET CategoryPath = 'UITemplates/', CategoryParentID = NULL, CategoryLevel = 0, CategoryOrder = 0  WHERE CategoryGUID = 'C1D43F2C-4886-4A7B-9681-291B272BBDD0'
GO

-- Update child count of '/' root
GO
UPDATE CMS_PageTemplateCategory SET CategoryChildCount =
(SELECT COUNT(*) FROM CMS_PageTemplateCategory WHERE CategoryParentID IN (SELECT CategoryID FROM CMS_PageTemplateCategory WHERE CategoryGUID = '532264BF-95E9-4035-B4CE-FE403C81781A')) WHERE CategoryGuid = '532264BF-95E9-4035-B4CE-FE403C81781A'
GO

-- HF-5 - Replace incorrect field caption of cms.role class
GO
UPDATE [CMS_Class] SET [ClassFormDefinition] = REPLACE([ClassFormDefinition],'<fieldcaption>Roles domain</fieldcaption>','<fieldcaption>Is domain role</fieldcaption>') WHERE [ClassName] = N'cms.Role'
GO


-- HF-68 - Remove testing rows from database
GO
DELETE FROM CMS_WorkflowTransition WHERE TransitionStartStepID IN (SELECT StepID FROM CMS_WorkflowStep WHERE StepWorkflowID = 634);
DELETE FROM CMS_WorkflowStep WHERE StepWorkflowID = 634;
DELETE FROM CMS_ObjectWorkflowTrigger WHERE TriggerWorkflowID = 486;
DELETE FROM CMS_ObjectWorkflowTrigger WHERE TriggerWorkflowID = 497;
DELETE FROM CMS_RoleUIElement WHERE ElementID IN (SELECT ElementID FROM CMS_UIElement WHERE ElementParentID = 4089);
DELETE FROM CMS_UIElement WHERE ElementParentID IN (SELECT ElementID FROM CMS_UIElement WHERE ElementParentID = 4089);
DELETE FROM CMS_UIElement WHERE ElementParentID = 4089;
DELETE FROM Reporting_ReportGraph WHERE GraphReportID IN (SELECT ReportID FROM Reporting_Report WHERE ReportCategoryID IN (SELECT categoryID FROM Reporting_ReportCategory WHERE CategoryParentID = 348));
DELETE FROM Reporting_Report WHERE ReportCategoryID IN (SELECT categoryID FROM Reporting_ReportCategory WHERE CategoryParentID = 348);
DELETE FROM Reporting_ReportCategory WHERE CategoryParentID = 348;
DELETE FROM CMS_WorkflowTransition WHERE TransitionWorkflowID = 634;
GO

--HF-65-Free edition-editor issue
GO
UPDATE CMS_User
SET UserIsEditor = 'False'
WHERE (UserIsGlobalAdministrator = 'True' AND UserIsEditor = 'True')
GO

-- HF-83 -- Clear overriden system properties for webpart 'repeater'
UPDATE CMS_WebPart SET WebPartDefaultValues = NULL WHERE WebPartGUID = '37FF87DF-9311-4210-A5D6-CFF3119C0BDB'
GO

-- HF-17 - Pages -> Analytics - Tabs related to A/B and MV testing were visible without appropriate license
GO
UPDATE CMS_UIElement SET ElementFeature = 'ABTesting' WHERE ElementName = 'OnlineMarketing.ABTests';
UPDATE CMS_UIElement SET ElementFeature = 'MVTesting' WHERE ElementName = 'OnlineMarketing.MVTests';
UPDATE CMS_UIElement SET ElementFeature = 'MVTesting' WHERE ElementName = 'OnlineMarketing.MVTVariants';
GO

-- HF-115 Group: Forum group: View tab
GO
UPDATE [CMS_UIElement] SET [ElementTargetURL] = N'~\CMSModules\Groups\Tools\Forums\Groups\ForumGroup_View.aspx?forumgroupid={?objectid?}' WHERE [ElementName] = N'GroupForumGroupEditTab_View'
GO

-- HF-125 UI templates didn't have correct child count in special cases
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 5
BEGIN
	UPDATE [CMS_PageTemplateCategory] SET 
	[CategoryChildCount] = (SELECT Count(*) FROM [CMS_PageTemplateCategory] AS [SUB] WHERE [SUB].[CategoryParentID] = [CMS_PageTemplateCategory].[CategoryID]),
	[CategoryTemplateChildCount] = (SELECT Count(*) FROM [CMS_PageTemplate] AS [SUB] WHERE [SUB].[PageTemplateCategoryID] = [CMS_PageTemplateCategory].[CategoryID])
END
GO

-- HF-180 Removal of testing data from metafiles
GO
DELETE FROM CMS_MetaFile WHERE MetaFileGUID = '329E34CC-1B37-4B2C-B60F-1D60205B9F21';
GO

-- HF-186 - Invalid macro expression was used in HTML code of "Div element" web part container.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 7
BEGIN
	UPDATE [CMS_WebPartContainer] SET [ContainerTextBefore] = N'<div class="{%ContainerCSSClass%}">', [ContainerTextAfter] = N'</div>' WHERE [ContainerGUID] = 'C278C678-A3F7-4FDC-AC4E-20CB69D9DE06'
END
GO

-- HF-202 - Invalid URLs in Banned IPs how to links.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 7
BEGIN
	UPDATE [CMS_HelpTopic]
	SET [HelpTopicLink] = 'IQEc'
	WHERE HelpTopicGUID IN ('EAABA0CF-F8A7-42EA-B0A4-22DC8368898B', '5A36B71F-E20B-43D6-A4EF-7E3BE3F77603')
END
GO

-- HF-245 - Queries belonging to a module in development need to be custom.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 9
BEGIN
	UPDATE [Q]
	SET [QueryIsCustom] = 1
	FROM [CMS_Query] AS [Q]
	JOIN [CMS_Class] AS [C] ON [Q].[ClassID] = [C].[ClassID]
	INNER JOIN [CMS_Resource] AS [R] ON [R].[ResourceID] = [C].[ClassResourceID]
	WHERE [Q].[QueryIsCustom] = 0 AND [R].[ResourceIsInDevelopment] = 1
END
GO

-- HF-260 - Control "Schedule Interval" shouldn't be listed under Form Controls.
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF @HOTFIXVERSION  < 9
BEGIN
	DELETE FROM [CMS_FormUserControl] WHERE [UserControlCodeName] = N'ScheduleInterval' AND [UserControlFileName] = N'~/CMSAdminControls/UI/Selectors/ScheduleInterval.ascx'
END
GO


-- HF-270 - Kentico did not switch content culture according to the preferred culture set in browser.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 9
BEGIN
	DECLARE @formDefinition xml;

	-- Store current form definition of CMS.Site class
	SELECT @formDefinition = [ClassFormDefinition] FROM [CMS_Class] WHERE [ClassName] = N'cms.site';

	-- Correct special fields
	SET @formDefinition.modify('replace value of (//field[@guid="ddfbfe8d-3b87-4785-b147-24a28f107937"]/settings/SpecialFields/text())[1] with ";{$Site_Edit.Automatic$}"');
	
	-- Correct DisplayNameFormat field
	SET @formDefinition.modify('delete (//field[@guid="ddfbfe8d-3b87-4785-b147-24a28f107937"]/settings/DisplayNameFormat)');
	SET @formDefinition.modify('insert <DisplayNameFormat>{"{%CultureName%}"}</DisplayNameFormat> into (//field[@guid="ddfbfe8d-3b87-4785-b147-24a28f107937"]/settings)[1]');

	-- Correct ReturnColumnName field
	SET @formDefinition.modify('replace value of (//field[@guid="ddfbfe8d-3b87-4785-b147-24a28f107937"]/settings/ReturnColumnName/text())[1] with ("CultureCode")');
	
	-- Update form definition of CMS.Site class
	UPDATE [CMS_Class] SET [ClassFormDefinition] = CONVERT(nvarchar(MAX), @formDefinition) WHERE [ClassName] = N'cms.site';

	-- Correct wrong values in SiteDefaultVisitorCulture column
	UPDATE [CMS_Site] SET [SiteDefaultVisitorCulture] = '' WHERE [SiteDefaultVisitorCulture] = '0'
END
GO

-- HF-256 - Macro signing process in previous versions was breaking some rule macros. This script inserts the same but workign macros when customer did not changed the original.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF  (@HOTFIXVERSION  < 9) AND (@HOTFIXVERSION  > 5)
BEGIN
	DECLARE @xml NVARCHAR(max)
	DECLARE @startIndex INT
	DECLARE @length INT
	DECLARE @pattern NVARCHAR(max)

	--Discount class
	DECLARE @macro NVARCHAR(max) = 'DiscountIsFlat.Value? true: Value&lt;=100'
	DECLARE @replacement NVARCHAR(max) = '<rule>{%Rule(&quot;DiscountIsFlat.Value? true: Value&lt;=100&quot;, &quot;&lt;rules&gt;&lt;r pos=\&quot;0\&quot; par=\&quot;\&quot; op=\&quot;and\&quot; n=\&quot;GeneralCondition\&quot; &gt;&lt;p n=\&quot;condition\&quot;&gt;&lt;t&gt;DiscountIsFlat.Value? true: Value&amp;lt;=100&lt;/t&gt;&lt;v&gt;DiscountIsFlat.Value? true: Value&amp;lt;=100&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;longtext&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;&quot;)@'

	SELECT @xml = [ClassFormDefinition]
	FROM [CMS_Class]
	WHERE [ClassName] = N'ecommerce.discount'

	-- Find macro
	SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '&quot;%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '"%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '|%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '|%', @xml)

	-- Find end of the macro
	SET @length = PATINDEX('%[%]}</rule>%', SUBSTRING(@xml, @startIndex, LEN(@xml))) - 1

	-- Replace
	if (@startIndex > 0 AND @length > 0)
	BEGIN
		SET @pattern = SUBSTRING(@xml, @startIndex, @length)
		SET @xml = REPLACE(@xml, @pattern, @replacement)
		UPDATE [CMS_Class] SET [ClassFormDefinition] = @xml WHERE [ClassName] = N'ecommerce.discount'
	END

	--Volume discount class
	SET @macro = 'VolumeDiscountIsFlatValue.Value? true : Value&lt;=100'
	SET  @replacement = '<rule>{%Rule(&quot;VolumeDiscountIsFlatValue.Value? true : Value&lt;=100&quot;, &quot;&lt;rules&gt;&lt;r pos=\&quot;0\&quot; par=\&quot;\&quot; op=\&quot;and\&quot; n=\&quot;GeneralCondition\&quot; &gt;&lt;p n=\&quot;condition\&quot;&gt;&lt;t&gt;VolumeDiscountIsFlatValue.Value? true : Value&amp;lt;=100&lt;/t&gt;&lt;v&gt;VolumeDiscountIsFlatValue.Value? true : Value&amp;lt;=100&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;longtext&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;&quot;)@'

	SELECT @xml = [ClassFormDefinition]
	FROM [CMS_Class]
	WHERE [ClassName] = N'ecommerce.volumediscount'

	-- Find macro
	SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '&quot;%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '"%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '|%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '|%', @xml)

	-- Find end of the macro
	SET @length = PATINDEX('%[%]}</rule>%', SUBSTRING(@xml, @startIndex, LEN(@xml))) - 1

	-- Replace
	if (@startIndex > 0 AND @length > 0)
	BEGIN
		SET @pattern = SUBSTRING(@xml, @startIndex, @length)
		SET @xml = REPLACE(@xml, @pattern, @replacement)
		UPDATE [CMS_Class] SET [ClassFormDefinition] = @xml WHERE [ClassName] = N'ecommerce.volumediscount'
	END

	--Option category class
	SET @macro = ' (CategoryType==\&quot;TEXT\&quot;)? (Convert.ToInt(CategoryDefaultOptions.Value.Length , 0) &lt;= Convert.ToInt(CategoryTextMaxLength.Value, 200)) : true '
	SET @replacement = '<rule>{%Rule(&quot; (CategoryType==\&quot;TEXT\&quot;)? (Convert.ToInt(CategoryDefaultOptions.Value.Length , 0) &lt;= Convert.ToInt(CategoryTextMaxLength.Value, 200)) : true &quot;, &quot;&lt;rules&gt;&lt;r pos=\&quot;0\&quot; par=\&quot;\&quot; op=\&quot;and\&quot; n=\&quot;GeneralCondition\&quot; &gt;&lt;p n=\&quot;condition\&quot;&gt;&lt;t&gt; (CategoryType==&amp;quot;TEXT&amp;quot;)? (Convert.ToInt(CategoryDefaultOptions.Value.Length , 0) &amp;lt;= Convert.ToInt(CategoryTextMaxLength.Value, 200)) : true &lt;/t&gt;&lt;v&gt; (CategoryType==&amp;quot;TEXT&amp;quot;)? (Convert.ToInt(CategoryDefaultOptions.Value.Length , 0) &amp;lt;= Convert.ToInt(CategoryTextMaxLength.Value, 200)) : true &lt;/v&gt;&lt;r&gt;0&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;longtext&lt;/vt&gt;&lt;tv&gt;0&lt;/tv&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;&quot;)@'

	SELECT @xml = [ClassFormDefinition]
	FROM [CMS_Class]
	WHERE [ClassName] = N'ecommerce.optioncategory'

	-- Find macro
	SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '&quot;%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '"%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '|%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '|%', @xml)

	-- Find end of the macro
	SET @length = PATINDEX('%[%]}</rule>%', SUBSTRING(@xml, @startIndex, LEN(@xml))) - 1

	-- Replace
	if (@startIndex > 0 AND @length > 0)
	BEGIN
		SET @pattern = SUBSTRING(@xml, @startIndex, @length)
		SET @xml = REPLACE(@xml, @pattern, @replacement)
		UPDATE [CMS_Class] SET [ClassFormDefinition] = @xml WHERE [ClassName] = N'ecommerce.optioncategory'
	END

	--Web part Media gallery
	SET @macro = 'Value.Matches(\&quot;^([[]^:*?&lt;&gt;{}\\\\\\\&quot;\\\&quot;|]*)+$\&quot;)'
	SET @replacement = '<rule>{%Rule(&quot;Value.Matches(\&quot;^([^:*?&lt;&gt;{}\\\\\\\&quot;\\\&quot;|]*)+$\&quot;)&quot;, &quot;&lt;rules&gt;&lt;r pos=\&quot;0\&quot; par=\&quot;\&quot; op=\&quot;and\&quot; n=\&quot;RegExp\&quot; &gt;&lt;p n=\&quot;regexp\&quot;&gt;&lt;t&gt;^([^:*?&amp;lt;&amp;gt;{}\\\\\\&amp;quot;\\&amp;quot;|]*)+$&lt;/t&gt;&lt;v&gt;^([^:*?&amp;lt;&amp;gt;{}\\\\\\&amp;quot;\\&amp;quot;|]*)+$&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;text&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;&quot;)@'

	SELECT @xml = [WebPartProperties]
	FROM [CMS_WebPart]
	WHERE [WebPartName] = N'MediaGallery'

	-- Find macro
	SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '&quot;%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '"%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule(&quot;' + @macro + '|%', @xml)
	if (@startIndex = 0) SET @startIndex = PATINDEX('%<rule>{[%]Rule("' + @macro + '|%', @xml)

	-- Find end of the macro
	SET @length = PATINDEX('%[%]}</rule>%', SUBSTRING(@xml, @startIndex, LEN(@xml))) - 1

	-- Replace
	if (@startIndex > 0 AND @length > 0)
	BEGIN
		SET @pattern = SUBSTRING(@xml, @startIndex, @length)
		SET @xml = REPLACE(@xml, @pattern, @replacement)
		UPDATE [CMS_WebPart] SET [WebPartProperties] = @xml WHERE [WebPartName] = N'MediaGallery'
	END
END
GO

-- HF-278 - "has not" doesn't work in some macros
GO
UPDATE CMS_MacroRule SET MacroRuleCondition = '{_perfectum}' + MacroRuleCondition WHERE MacroRuleText LIKE 'Contact {_perfectum}%' AND MacroRuleCondition NOT LIKE '%{_perfectum}%'
GO

-- HF-281 - Allow to create a new query only for editable module (hide new query UI element otherwise)
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF  @HOTFIXVERSION  < 9
BEGIN
	UPDATE [CMS_UIElement]
	SET [ElementVisibilityCondition] = '{%System.GetObject("cms.resource",Convert.ToInt(QueryString.moduleId, 0)).IsEditable @%}'
	WHERE [ElementGUID] = 'EF61DD0C-0100-4D31-A6F7-D6516B294EDF'
END
GO

-- HF-287 - Show navigation control didn't work in google maps web parts because of change their API
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION =  (SELECT KeyValue FROM [CMS_SettingsKey] WHERE KeyName = N'CMSHotfixVersion')
IF  @HOTFIXVERSION  < 10
BEGIN
	UPDATE [CMS_WebPart]
	SET [WebPartProperties] = '<form version="2"><category name="Location"><properties><visible>true</visible></properties></category><field column="DefaultLocation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" guid="d02a92c8-865e-4dd0-b797-749a7b4f41b0" visibility="none" reftype="Required"><properties><fielddescription>The middle point of the large view map initial location - used when the map is displayed on page load. Used only when the ''Latitude'' and ''Longtitude'' properties are not defined. Not used in the detail mode. For better performance and more accurate results please use the ''Latitude'' and ''Longtitude'' properties instead. The accepted value is any valid address.

Example: ''Windsor, Ontario, CA''</fielddescription><fieldcaption>Default location or address</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Latitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="beb664dc-e592-4319-ba00-fb5fe85c278f" visibility="none" reftype="Required"><properties><fielddescription>Initial latitude of the large view map middle point - used when the map is displayed on page load. Accepted values range from -90 to 90.</fielddescription><fieldcaption>Default latitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Longitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="098541d6-f430-4b3f-a05b-2f1c3d49b9c0" visibility="none" reftype="Required"><properties><fielddescription>Initial longitude of the large view map middle point - used when the map is displayed on page load. Accepted values range from -180 to 180.</fielddescription><fieldcaption>Default longitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="LocationField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="142b33fe-23c8-44b7-b66b-702fdea8964b" visibility="none" reftype="Required"><properties><fielddescription>Code name of the location source field in the source document type, i.e. the document type used for the location markers displayed on the map. Used only when the latitude and longtitude source document field values are not defined. For better performance and more accurate results please use the ''LatitudeField'' and ''LongtitudeField'' properties instead.</fielddescription><fieldcaption>Location field</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="LatitudeField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="3d766223-64d0-4ad7-9eaf-a1617440a31d" visibility="none" reftype="Required"><properties><fielddescription>Code name of the latitude source field in the source document type, i.e. the document type used for the location markers displayed on the map.</fielddescription><fieldcaption>Latitude field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="LongitudeField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="a5cd032b-86a2-4bfe-967c-340eba791f8e" visibility="none" reftype="Required"><properties><fielddescription>Code name of the longitude source field in the source document type, i.e. the document type used for the location markers displayed on the map.</fielddescription><fieldcaption>Longitude field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="EnableServerProcessing" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="c42d23a6-1ca8-4ec9-aacc-19365a634b7a" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the geolocation translations (addresses to coordinates) are processed by the server or client. If
true, the application itself processes human-readable locations and translates them into coordinates. If false, client-side processing is used. Used only if the location is available in human-readable form and if no coordinates are specified or zero.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Use server processing</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Content"><properties><visible>true</visible></properties></category><field column="Path" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="450" publicfield="false" guid="b59e17fc-d42c-4325-8fac-ae199ea266c2" visibility="none" reftype="Required"><properties><fielddescription>Path to the documents which should be displayed on the map as location markers.</fielddescription><fieldcaption>Path</fieldcaption></properties><settings><controlname>selectpath</controlname></settings></field><category name="Content filter"><properties><visible>true</visible></properties></category><field column="ClassNames" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="400" publicfield="false" guid="ea368abb-cce9-4b20-8943-65983a280bba" visibility="none" reftype="Required"><properties><fielddescription>Types of documents (within the location specified by the Path property) which should be displayed on the map as location markers.</fielddescription><fieldcaption>Document types</fieldcaption></properties><settings><controlname>selectclassnames</controlname><ShowOnlyCoupled>False</ShowOnlyCoupled></settings></field><field column="CombineWithDefaultCulture" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="5" publicfield="false" guid="399cf947-bf40-44fd-b56e-273fbc81f264" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.combinewithculture$}</fielddescription><fieldcaption>Combine with default culture</fieldcaption></properties><settings><RepeatDirection>vertical</RepeatDirection><controlname>radiobuttonscontrol</controlname><Options>true;Yes
false;No
;Use site settings</Options></settings></field><field column="CultureCode" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="20" publicfield="false" guid="fab5f8ab-cf2e-4408-bea1-f1047f1714a8" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.culturecode$}</fielddescription><fieldcaption>Culture code</fieldcaption></properties><settings><controlname>selectculture</controlname></settings></field><field column="MaxRelativeLevel" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="cfa2eba1-bb78-4410-8043-d865109bc86a" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.maxnestinglevel$}</fielddescription><defaultvalue>-1</defaultvalue><fieldcaption>Maximum nesting level</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="OrderBy" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="500" publicfield="false" guid="8cbd862b-b10c-426d-b168-ed7085c2d509" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.orderby$}</fielddescription><fieldcaption>ORDER BY expression</fieldcaption></properties><settings><controlname>orderby</controlname></settings></field><field column="SelectOnlyPublished" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="5a04c4ca-4a2c-474a-ad80-4009d0119b04" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.selectpublished$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Select only published</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="SelectTopN" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="28c3d4c6-7bec-4d23-9435-6c7b9db0dc81" visibility="none" reftype="Required"><properties><fielddescription>Selects top N document types from the Document types field.</fielddescription><fieldcaption>Select top N documents</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="SiteName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="526eea01-6dcd-4d0c-bac5-8465aec604d1" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.sitename$}</fielddescription><fieldcaption>Site name</fieldcaption></properties><settings><controlname>selectsite</controlname></settings></field><field column="WhereCondition" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="500" publicfield="false" guid="b3a1afd8-de95-42b5-90a0-891543dc3e61" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.where$}</fielddescription><fieldcaption>WHERE condition</fieldcaption></properties><settings><controlname>wherecondition</controlname></settings></field><field column="FilterOutDuplicates" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="9be42ea6-bf70-48fc-9477-2230f4a26cb8" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.filterduplicates$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Filter out duplicate documents</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableSelectedItem" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="66a9ea5a-1f8b-4250-9963-afc3968a8219" reftype="Required"><properties><fielddescription>Gets or sets the value that indicates if current document is in classnames only this document is displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Enable selected item</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Transformations"><properties><visible>true</visible></properties></category><field column="TransformationName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" guid="d62753d4-2b3f-43ca-9e1d-45daec6e9fad" visibility="none" reftype="Required"><properties><fielddescription>Transformation used for the content of the tooltip displayed when a location marker is clicked.</fielddescription><fieldcaption>Transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><category name="Map properties"><properties><visible>true</visible></properties></category><field column="Scale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="becee78d-3281-44e1-aa14-5cc0f6a22d4e" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the large view used on page load. Values range from 0 (the most distant view) to 19 (the nearest view).</fielddescription><defaultvalue>3</defaultvalue><fieldcaption>Large view scale</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode></settings><rules><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;integer&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;integer&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="ZoomScale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="e616c730-2538-4a84-9d00-b55e56641f10" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the zoomed view displayed after clicking a defined location marker on the map. Values range from 0 (the most distant view)to 19 (the nearest view).</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Detailed view scale</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><rules><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;integer&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;integer&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="Width" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="32" publicfield="false" guid="aeacce47-5459-417d-97c7-c9edd471dc4e" visibility="none" reftype="Required"><properties><fielddescription>Width of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Width</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Height" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="32" publicfield="false" guid="b2ad9df7-3a67-43f2-9d61-93be76f3c89c" visibility="none" reftype="Required"><properties><fielddescription>Height of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Height</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="ToolTipField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="f0237e3c-952b-4698-af07-b3099a5ade8d" visibility="none" reftype="Required"><properties><fielddescription>Code name of the document type field whose content will be used as a header of the tool-tip displayed when a location marker is clicked.</fielddescription><fieldcaption>Tooltip field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="IconField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="84c6c55d-595c-41af-9341-cb92cbdf1dc3" visibility="none" reftype="Required"><properties><fielddescription>Code name of the source field whose content will be used as URL for the custom map icon.</fielddescription><fieldcaption>Icon field</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="MapType" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="02ad68af-30c8-4fb3-9916-3c99247b37dd" visibility="none" reftype="Required"><properties><fielddescription>Initial map type used on page load:

ROADMAP - This map type displays a normal street map.

SATELLITE - This map type displays a transparent layer of major streets on satellite images.

HYBRID - This map type displays a transparent layer of major streets on satellite images.

TERRAIN - This map type displays maps with physical features such as terrain and vegetation.</fielddescription><defaultvalue>ROADMAP</defaultvalue><fieldcaption>Map type</fieldcaption></properties><settings><options>&lt;item value="ROADMAP" text="Roadmap" /&gt;&lt;item value="SATELLITE" text="Satellite" /&gt;&lt;item value="HYBRID" text="Hybrid" /&gt;&lt;item value="TERRAIN" text="Terrain" /&gt;</options><controlname>dropdownlistcontrol</controlname></settings></field><field column="ShowNavigationControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="150e9473-56ff-478b-ae44-e779d6f8bf8a" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the navigation control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show navigation control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="NavigationControlType" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="efe56520-e3b3-460e-9ceb-6f88a77d3675" visibility="none" reftype="Required" resolvedefaultvalue="False"><properties><fielddescription>Type of the zoom control:

Default - The default zoom control. The control which DEFAULT maps to will vary according to map size and other factors.

Small - displays a mini-zoom control, consisting of only + and - buttons. This style is appropriate for mobile devices.

Large - displays the larger control, with the zoom slider in addition to +/- buttons.</fielddescription><fieldcaption>Zoom control type</fieldcaption></properties><settings><Options>0;Default
1;Small
2;Large</Options><SortItems>False</SortItems><EditText>False</EditText><controlname>DropDownListControl</controlname></settings></field><field column="ShowScaleControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="4978c2e1-aaaa-426d-b7bd-f36f9588fb57" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the scale bar in the bottom left corner of the map is displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show scale control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ShowMapTypeControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="ac715ba7-8bdb-4dba-abd9-5b5867656630" reftype="Required"><properties><fielddescription>Indicates if the map type control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show map type selection</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableMapDragging" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="f7756896-f791-415f-8fae-039611929ed5" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the map dragging is enabled.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Enable map dragging</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableKeyboardShortcuts" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="bca1b061-e7de-4f37-ba53-670972acd956" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the keyboard shortcuts are enabled.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Enable keyboard shortcuts</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="No data behavior"><properties><visible>true</visible></properties></category><field column="HideControlForZeroRows" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="becfddac-85c6-4a8f-abd4-fd8d80c82a5a" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hidenofound$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide if no record found</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ZeroRowsText" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="b7cfb96f-e8bb-4f41-9506-ff1bc26bf9b8" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.norecordtext$}</fielddescription><fieldcaption>No record found text</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><category name="System settings"><properties><visible>true</visible></properties></category><field column="CheckPermissions" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="3386e313-80f4-4998-a323-39b51c7deaba" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.checkperm$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Check permissions</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="CacheItemName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="94a16b2e-3d40-436c-a5aa-5a826bbcb36d" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheitemname$}</fielddescription><fieldcaption>Cache item name</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="CacheMinutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="45bc8955-8530-4dc7-bd98-92891c1fb5e2" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheminutes$}</fielddescription><fieldcaption>Cache minutes</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="CacheDependencies" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="3c146105-668c-4415-b148-14e15cd60ac7" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cachedependencies$}</fielddescription><fieldcaption>Cache dependencies</fieldcaption></properties><settings><controlname>cachedependencies</controlname></settings></field><category name="AJAX"><properties><visible>true</visible></properties></category><field column="UseUpdatePanel" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="c5f236b0-d8e0-41e5-b848-ee5b9b0f672c" visibility="none" reftype="Required"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
	WHERE [WebPartName] = 'GoogleMaps'

	UPDATE [CMS_WebPart]
	SET [WebPartProperties] = '<form version="2"><category name="Location"><properties><visible>True</visible></properties></category><field column="DefaultLocation" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" guid="d02a92c8-865e-4dd0-b797-749a7b4f41b0" visibility="none" reftype="Required"><properties><fielddescription>The middle point of the large view map initial location - used when the map is displayed on page load. Used only when the ''Latitude'' and ''Longtitude'' properties are not defined. Not used in the detail mode. For better performance and more accurate results please use the ''Latitude'' and ''Longtitude'' properties instead. The accepted value is any valid address.

Example: ''Windsor, Ontario, CA''</fielddescription><fieldcaption>Default location or address</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Latitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="beb664dc-e592-4319-ba00-fb5fe85c278f" visibility="none" reftype="Required"><properties><fielddescription>Initial latitude of the large view map middle point - used when the map is displayed on page load. Accepted values range from -90 to 90.</fielddescription><fieldcaption>Default latitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Longitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="098541d6-f430-4b3f-a05b-2f1c3d49b9c0" visibility="none" reftype="Required"><properties><fielddescription>Initial longitude of the large view map middle point - used when the map is displayed on page load. Accepted values range from -180 to 180.</fielddescription><fieldcaption>Default longitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="LocationField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" spellcheck="false" guid="142b33fe-23c8-44b7-b66b-702fdea8964b" visibility="none" reftype="Required"><properties><fielddescription>Code name of the location source field in the source document type, i.e. the document type used for the location markers displayed on the map. Used only if the latitude and longtitude source document field values are not defined. For better performance and more accurate results please use the ''LatitudeField'' and ''LongtitudeField'' properties instead.</fielddescription><fieldcaption>Location field</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="LatitudeField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="3d766223-64d0-4ad7-9eaf-a1617440a31d" visibility="none" reftype="Required"><properties><fielddescription>Code name of the latitude source field in the source document type, i.e. the document type used for the location markers displayed on the map.</fielddescription><fieldcaption>Latitude field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="LongitudeField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="a5cd032b-86a2-4bfe-967c-340eba791f8e" visibility="none" reftype="Required"><properties><fielddescription>Code name of the longitude source field in the source document type, i.e. the document type used for the location markers displayed on the map.</fielddescription><fieldcaption>Longitude field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="EnableServerProcessing" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="c42d23a6-1ca8-4ec9-aacc-19365a634b7a" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the geolocation translations (addresses to coordinates) are processed by the server or client. If
true, the application itself processes human-readable locations and translates them into coordinates. If false, client-side processing is used. Used only if the location is available in human-readable form and if no coordinates are specified or zero.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Use server processing</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="Content"><properties><visible>True</visible></properties></category><field column="DataSourceName" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="200" publicfield="false" guid="b59e17fc-d42c-4325-8fac-ae199ea266c2" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.datasourcename$}</fielddescription><fieldcaption>Data source name</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><category name="Transformations"><properties><visible>True</visible></properties></category><field column="TransformationName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" guid="d62753d4-2b3f-43ca-9e1d-45daec6e9fad" visibility="none" reftype="Required"><properties><fielddescription>Transformation used for the content of the tooltip displayed when a location marker is clicked.</fielddescription><fieldcaption>Transformation</fieldcaption></properties><settings><controlname>selecttransformation</controlname></settings></field><category name="Map properties"><properties><visible>True</visible></properties></category><field column="Scale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="becee78d-3281-44e1-aa14-5cc0f6a22d4e" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the large view used on page load. Values range from 0 (the most distant view) to 19 (the nearest view).</fielddescription><defaultvalue>3</defaultvalue><fieldcaption>Large view scale</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><rules><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="ZoomScale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="e616c730-2538-4a84-9d00-b55e56641f10" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the zoomed view displayed after clicking a defined location marker on the map. Values range from 0 (the most distant view) to 19 (the nearest view).</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Detailed view scale</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><rules><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="Width" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="32" publicfield="false" guid="aeacce47-5459-417d-97c7-c9edd471dc4e" visibility="none" reftype="Required"><properties><fielddescription>Width of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Width</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Height" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="32" publicfield="false" guid="b2ad9df7-3a67-43f2-9d61-93be76f3c89c" visibility="none" reftype="Required"><properties><fielddescription>Height of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Height</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="ToolTipField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="f0237e3c-952b-4698-af07-b3099a5ade8d" visibility="none" reftype="Required"><properties><fielddescription>Code name of the document type field whose content will be used as a header of the tool-tip displayed when a location marker is clicked.</fielddescription><fieldcaption>Tooltip field</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="IconField" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="f6fd3f34-7e0d-4891-a8a6-bc0a2c029649" visibility="none" reftype="Required"><properties><fielddescription>Code name of the source field whose content will be used as URL for the custom map icon.</fielddescription><fieldcaption>Icon field</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="MapType" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="02ad68af-30c8-4fb3-9916-3c99247b37dd" visibility="none" reftype="Required"><properties><fielddescription>Initial map type used on page load:

ROADMAP - This map type displays a normal street map.

SATELLITE - This map type displays a transparent layer of major streets on satellite images.

HYBRID - This map type displays a transparent layer of major streets on satellite images.

TERRAIN - This map type displays maps with physical features such as terrain and vegetation.</fielddescription><defaultvalue>ROADMAP</defaultvalue><fieldcaption>Map type</fieldcaption></properties><settings><options>&lt;item value="ROADMAP" text="Roadmap" /&gt;&lt;item value="SATELLITE" text="Satellite" /&gt;&lt;item value="HYBRID" text="Hybrid" /&gt;&lt;item value="TERRAIN" text="Terrain" /&gt;</options><controlname>dropdownlistcontrol</controlname></settings></field><field column="ShowNavigationControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="150e9473-56ff-478b-ae44-e779d6f8bf8a" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the navigation control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show navigation control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="NavigationControlType" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="efe56520-e3b3-460e-9ceb-6f88a77d3675" visibility="none" reftype="Required" resolvedefaultvalue="False"><properties><fielddescription>Type of the zoom control:

Default - The default zoom control. The control which DEFAULT maps to will vary according to map size and other factors.

Small - displays a mini-zoom control, consisting of only + and - buttons. This style is appropriate for mobile devices.

Large - displays the larger control, with the zoom slider in addition to +/- buttons.</fielddescription><fieldcaption>Zoom control type</fieldcaption></properties><settings><Options>0;Default
1;Small
2;Large</Options><SortItems>False</SortItems><EditText>False</EditText><controlname>DropDownListControl</controlname></settings></field><field column="ShowScaleControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="4978c2e1-aaaa-426d-b7bd-f36f9588fb57" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the scale bar in the bottom left corner of the map should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show scale control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ShowMapTypeControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="ac715ba7-8bdb-4dba-abd9-5b5867656630" reftype="Required"><properties><fielddescription>Indicates if the map type control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show map type selection</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableMapDragging" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="f7756896-f791-415f-8fae-039611929ed5" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the map dragging is enabled.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Enable map dragging</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableKeyboardShortcuts" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="bca1b061-e7de-4f37-ba53-670972acd956" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the keyboard shortcuts are enabled.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Enable keyboard shortcuts</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="No data behavior"><properties><visible>True</visible></properties></category><field column="HideControlForZeroRows" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="617bcda3-b7b8-4eea-b476-7180fd44a596" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hidenofound$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide if no record found</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ZeroRowsText" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="b7d09143-4383-4ab0-9bbc-b8cd4f8f96e7" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.norecordtext$}</fielddescription><fieldcaption>No record found text</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><category name="AJAX"><properties><visible>True</visible></properties></category><field column="UseUpdatePanel" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="3c54bccf-ffc2-4f39-84c8-7eadde57ffc8" visibility="none" reftype="Required"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
	WHERE [WebPartName] = 'BasicGoogleMaps'

	UPDATE [CMS_WebPart]
	SET [WebPartProperties] = '<form version="2"><category name="Location"><properties><visible>True</visible></properties></category><field column="Location" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="250" publicfield="false" guid="d02a92c8-865e-4dd0-b797-749a7b4f41b0" visibility="none" reftype="Required"><properties><fielddescription>Used only if the ''Latitude'' and ''Longtitude'' properties are not defined. For better performance and more accurate results please use the ''Latitude'' and ''Longtitude'' properties instead. The accepted value is any valid address.

Example: ''Windsor, Ontario, CA''</fielddescription><fieldcaption>Location or address</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="EnableServerProcessing" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="c42d23a6-1ca8-4ec9-aacc-19365a634b7a" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the geolocation translations (addresses to coordinates) are processed by the server or client. If
true, the application itself processes human-readable locations and translates them into coordinates. If false, client-side processing is used. Used only if the location is available in human-readable form and if no coordinates are specified or zero.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Use server processing</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="Latitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="beb664dc-e592-4319-ba00-fb5fe85c278f" visibility="none" reftype="Required"><properties><fielddescription>Latitude of the marker. Accepted values range from -90 to 90.</fielddescription><fieldcaption>Latitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Longitude" visible="true" columntype="double" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="098541d6-f430-4b3f-a05b-2f1c3d49b9c0" visibility="none" reftype="Required"><properties><fielddescription>Longitude of the marker. Accepted values range from -180 to 180.</fielddescription><fieldcaption>Longitude</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><category name="Content"><properties><visible>True</visible></properties></category><field column="ToolTip" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="f0237e3c-952b-4698-af07-b3099a5ade8d" visibility="none" reftype="Required"><properties><fielddescription>Header of the tool-tip displayed when a location marker is clicked.</fielddescription><fieldcaption>Tooltip</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="Content" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="acd75178-a39c-40a7-bceb-a164a4eeff83" visibility="none" reftype="Required"><properties><fielddescription>Marker content.</fielddescription><fieldcaption>Marker content</fieldcaption></properties><settings><Width>500</Width><Height>250</Height><Autoresize_Hashtable>True</Autoresize_Hashtable><DisplayAutoResize>True</DisplayAutoResize><Dialogs_Libraries_Site>##all##</Dialogs_Libraries_Site><Dialogs_Content_Hide>False</Dialogs_Content_Hide><Dialogs_Content_Site>##all##</Dialogs_Content_Site><DisplayEmailTabSetting>True</DisplayEmailTabSetting><controlname>htmlareacontrol</controlname><MediaDialogConfiguration>True</MediaDialogConfiguration></settings></field><category name="Map properties"><properties><visible>True</visible></properties></category><field column="Scale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="becee78d-3281-44e1-aa14-5cc0f6a22d4e" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the large view used on page load. Values range from 0 (the most distant view) to 19 (the nearest view).</fielddescription><defaultvalue>3</defaultvalue><fieldcaption>Large view scale</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><rules><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="IconURL" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="175dba28-fbec-468d-98d2-8f554a0b9de9" visibility="none" reftype="Required"><properties><fielddescription>Custom marker icon URL.</fielddescription><fieldcaption>Icon URL</fieldcaption></properties><settings><Configuration>True</Configuration><controlname>urlselector</controlname><Dialogs_Content_Hide>False</Dialogs_Content_Hide></settings></field><field column="ZoomScale" visible="true" columntype="integer" fieldtype="CustomUserControl" publicfield="false" guid="e616c730-2538-4a84-9d00-b55e56641f10" visibility="none" reftype="Required"><properties><fielddescription>Scale value (zoom ratio) for the zoomed view displayed after clicking a defined location marker on the map. Values range from 0 (the most distant view) to 19 (the nearest view).</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Detailed view scale</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><rules><rule>{%Rule("Value &gt;= 0", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MinValue\" &gt;&lt;p n=\"minvalue\"&gt;&lt;t&gt;0&lt;/t&gt;&lt;v&gt;0&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule><rule>{%Rule("Value &lt;= 19", "&lt;rules&gt;&lt;r pos=\"0\" par=\"\" op=\"and\" n=\"MaxValue\" &gt;&lt;p n=\"maxvalue\"&gt;&lt;t&gt;19&lt;/t&gt;&lt;v&gt;19&lt;/v&gt;&lt;r&gt;false&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;double&lt;/vt&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;")%}</rule></rules></field><field column="Width" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="32" publicfield="false" guid="aeacce47-5459-417d-97c7-c9edd471dc4e" visibility="none" reftype="Required"><properties><fielddescription>Width of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Width</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Height" visible="true" columntype="text" fieldtype="CustomUserControl" columnsize="32" publicfield="false" guid="b2ad9df7-3a67-43f2-9d61-93be76f3c89c" visibility="none" reftype="Required"><properties><fielddescription>Height of the displayed map in pixels.</fielddescription><defaultvalue>400</defaultvalue><fieldcaption>Height</fieldcaption></properties><settings><FilterType>0</FilterType><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="MapType" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="100" publicfield="false" guid="02ad68af-30c8-4fb3-9916-3c99247b37dd" visibility="none" reftype="Required"><properties><fielddescription>Initial map type used on page load:

ROADMAP - This map type displays a normal street map.

SATELLITE - This map type displays a transparent layer of major streets on satellite images.

HYBRID - This map type displays a transparent layer of major streets on satellite images.

TERRAIN - This map type displays maps with physical features such as terrain and vegetation.</fielddescription><defaultvalue>ROADMAP</defaultvalue><fieldcaption>Map type</fieldcaption></properties><settings><options>&lt;item value="ROADMAP" text="Roadmap" /&gt;&lt;item value="SATELLITE" text="Satellite" /&gt;&lt;item value="HYBRID" text="Hybrid" /&gt;&lt;item value="TERRAIN" text="Terrain" /&gt;</options><controlname>dropdownlistcontrol</controlname></settings></field><field column="ShowNavigationControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="150e9473-56ff-478b-ae44-e779d6f8bf8a" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the navigation control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show navigation control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="NavigationControlType" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="efe56520-e3b3-460e-9ceb-6f88a77d3675" visibility="none" reftype="Required" resolvedefaultvalue="False"><properties><fielddescription>Type of the zoom control:

Default - The default zoom control. The control which DEFAULT maps to will vary according to map size and other factors.

Small - displays a mini-zoom control, consisting of only + and - buttons. This style is appropriate for mobile devices.

Large - displays the larger control, with the zoom slider in addition to +/- buttons.</fielddescription><fieldcaption>Zoom control type</fieldcaption></properties><settings><Options>0;Default
1;Small
2;Large</Options><SortItems>False</SortItems><EditText>False</EditText><controlname>DropDownListControl</controlname></settings></field><field column="ShowScaleControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="4978c2e1-aaaa-426d-b7bd-f36f9588fb57" visibility="none" reftype="Required"><properties><fielddescription>Indicates if the scale bar in the bottom left corner of the map should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show scale control</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="ShowMapTypeControl" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="ac715ba7-8bdb-4dba-abd9-5b5867656630" reftype="Required"><properties><fielddescription>Indicates if the map type control should be displayed.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show map type selection</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableMapDragging" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="f7756896-f791-415f-8fae-039611929ed5" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the map dragging is enabled.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Enable map dragging</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="EnableKeyboardShortcuts" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="bca1b061-e7de-4f37-ba53-670972acd956" visibility="none" reftype="Required"><properties><fielddescription>Indicates whether the keyboard shortcuts are enabled.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Enable keyboard shortcuts</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="System settings"><properties><visible>True</visible></properties></category><field column="CacheItemName" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" spellcheck="false" guid="6c54915b-c967-4d21-a7f7-58747fff5b5b" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheitemname$}</fielddescription><fieldcaption>Cache item name</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><field column="CacheMinutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" spellcheck="false" guid="622c2e40-bdd4-44e7-b5d8-a64efebe6030" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheminutes$}</fielddescription><defaultvalue>10</defaultvalue><fieldcaption>Cache minutes</fieldcaption></properties><settings><controlname>textboxcontrol</controlname></settings></field><category name="AJAX"><properties><visible>True</visible></properties></category><field column="UseUpdatePanel" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="4ee1c8fa-038f-4015-8b36-e561e26462e3" visibility="none" reftype="Required"><properties><defaultvalue>false</defaultvalue></properties><settings><controlname>checkboxcontrol</controlname></settings></field></form>'
	WHERE [WebPartName] = 'StaticGoogleMaps'

	UPDATE [CMS_Widget]
	SET [WidgetProperties] = '<form version="2"><field column="LocationField" visible="" /><field column="LatitudeField" visible=""><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="LongitudeField" visible=""><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="EnableServerProcessing" visible=""><properties><fielddescription>Indicates if the location translations (addresses to coordinates) are processed on server side. If false, client side processing is used.
Used only when location is available in human-readable form and when no coordinates are specified or zero.</fielddescription></properties></field><field column="Path" visible="" /><field column="ClassNames" visible="" /><field column="CombineWithDefaultCulture" visible="" /><field column="CultureCode" visible="" /><field column="MaxRelativeLevel" visible="" /><field column="OrderBy" visible="" /><field column="SelectOnlyPublished" visible="" /><field column="SelectTopN" visible="" /><field column="SiteName" visible="" /><field column="WhereCondition" visible="" /><field column="FilterOutDuplicates" visible="" /><field column="EnableSelectedItem" visible="" /><field column="TransformationName" visible="" /><field column="ToolTipField" visible="" /><field column="IconField" visible="" /><field column="ShowNavigationControl" visible="" /><field column="NavigationControlType" visible="" /><field column="ShowScaleControl" visible="" /><field column="ShowMapTypeControl" visible="" /><field column="EnableMapDragging" visible="" /><field column="EnableKeyboardShortcuts" visible="" /><field column="HideControlForZeroRows" visible="" spellcheck=""><settings><controlname /></settings><properties><fielddescription /><fieldcaption /></properties></field><field column="ZeroRowsText" visible=""><properties><fielddescription>Text that should be displayed if no records are found. This text will not be visible if the Hide if no record found property of the web part is enabled.</fielddescription></properties></field><field column="CheckPermissions" visible=""><properties><fielddescription>Indicates if the permissions of the current user should be checked for the content of the web part. If enabled, only documents for which the user has the "read" permission will be loaded.</fielddescription></properties></field><field column="CacheItemName" visible=""><properties><fielddescription>Sets the name of the cache key used for the content of the web part. If not specified, this name is generated automatically based on the site, document path, Web part control ID and current user. A cache key can be shared between multiple web parts with the same content on different pages in order to avoid keeping redundant data in the memory.</fielddescription></properties></field><field column="CacheMinutes" visible=""><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings><properties><fielddescription>Sets the number of minutes for which the content of the web part should remain cached before its latest version is reloaded from the database. If left empty, the value entered in settings System -&gt; Performance -&gt; Cache content (minutes) setting will be used instead. If set to 0, caching will be disabled for the web part.</fielddescription></properties></field><field column="CacheDependencies" visible=""><properties><fielddescription>Contains a list of cache keys on which the partial cache of the web part depends. When the specified cache items change, the partial cache of the web part is deleted. Each line may only contain a single item. If the Use default cache dependencies box is checked, the default dependencies will be used, which include all possible object changes that could affect the specific web part.</fielddescription></properties></field></form>'
	WHERE [WidgetName] = 'GoogleMaps'

	UPDATE [CMS_Widget]
	SET [WidgetProperties] = '<form version="2"><field column="EnableServerProcessing" visible="" /><field column="ToolTip"><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="Content"><settings><ToolbarSet>Widgets</ToolbarSet><DisplayAutoResize /><DisplayEmailTabSetting /></settings></field><field column="IconURL" visible="" /><field column="MapType"><settings><options>ROADMAP;Roadmap
SATELLITE;Satellite
HYBRID;Hybrid
TERRAIN;Terrain</options></settings></field><field column="ShowNavigationControl" visible="" /><field column="NavigationControlType" visible=""><properties><defaultvalue>0</defaultvalue></properties></field><field column="ShowScaleControl" visible="" /><field column="ShowMapTypeControl" visible="" /><field column="EnableMapDragging" visible="" /><field column="EnableKeyboardShortcuts" visible="" /><field column="CacheItemName" visible="" /><field column="CacheMinutes" visible="" /></form>'
	WHERE [WidgetName] = 'StaticGoogleMaps'
END
GO

-- HF-276 - Add required data to macro rules using AutomationState context
GO
UPDATE [CMS_MacroRule] SET [MacroRuleRequiredData] = 'AutomationState' WHERE [MacroRuleCondition] LIKE '%AutomationState.%'
GO


-- HF-290 - When renaming document the children DoucmentURLPath is incorrectly generated and document aliases were not created for children in non-default culture when settings 'Remember original URLs when moving documents' and 'Use name path for URL path' were used
GO
ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10),
 @GenerateAliases bit
AS
BEGIN
	DECLARE @parents TABLE (
		NodeParentID int,
		DocumentCulture nvarchar(10)
	);

	-- Get all parents
	INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID
	
	DECLARE @nodeParentId int;
	DECLARE @parentDocumentCulture nvarchar(10);

	DECLARE @parentUseNamePathForUrlPath bit;
	DECLARE @parentDocumentUrlPath nvarchar(450);
	DECLARE @parentDocumentNamePath nvarchar(1500);
	  
	DECLARE @documentUseNamePathForUrlPath bit;

	-- Flag that indicates if procedure should be proceed another level
	DECLARE @updateChildren bit;

	DECLARE @parentCursor CURSOR;
	SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
	
	OPEN @parentCursor
	FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Temporary table for nodes
		DECLARE @nodes TABLE (
		NodeID int,
		DocumentCulture nvarchar(10),
		DocumentURLPath nvarchar(450),
		NodeLinkedNodeID int,
		DocumentUseNamePathForUrlPath bit
		);

		-- Get parent document URL path and name path
		SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath FROM
			(SELECT TOP 1 NodeLinkedNodeID, DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID, NodeLinkedNodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
			FROM View_CMS_Tree_Joined WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
			ORDER BY Priority ASC) TopParentPath;
    
		
		IF (@GenerateAliases = 1)
		BEGIN
			-- Get all children with old values
			INSERT INTO @nodes 
				SELECT NodeID, DocumentCulture, DocumentURLPath, NodeLinkedNodeID, DocumentUseNamePathForUrlPath
				FROM View_CMS_Tree_Joined 
				WHERE NodeParentID = @nodeParentId;
		END
				
		-- Update URL path and name path in the parent node culture
		UPDATE CMS_Document SET 
			DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, 
			DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND @parentDocumentUrlPath <> '' AND  DocumentUrlPath <> '' THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
			WHERE DocumentNodeID IN (SELECT NodeID 
									FROM CMS_Tree 
									WHERE NodeParentID = @nodeParentId) AND DocumentCulture = @parentDocumentCulture
		
		IF @@ROWCOUNT <> 0
		BEGIN
			SET @updateChildren = 1;
		END

		IF (@GenerateAliases = 1)
		BEGIN
			DECLARE @newDocumentURLPath nvarchar(450);
			DECLARE @nodeDocumentUrlPath nvarchar(450);
			DECLARE @nodeDocumentCulture nvarchar(10);
			DECLARE @nodeLinkedNodeId int;
			DECLARE @nodeId int;

			DECLARE @nodesCursor CURSOR;
			SET @nodesCursor = CURSOR FOR SELECT NodeID, DocumentCulture, DocumentURLPath, NodeLinkedNodeID, DocumentUseNamePathForUrlPath FROM @nodes;
 
			OPEN @nodesCursor
			FETCH NEXT FROM @nodesCursor INTO @nodeId, @nodeDocumentCulture, @nodeDocumentUrlPath, @nodeLinkedNodeId, @documentUseNamePathForUrlPath
			WHILE @@FETCH_STATUS = 0
			BEGIN

				-- Create new document URL path to check that is different than before
				SET @newDocumentURLPath = CASE WHEN @documentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath,'') != '') AND  (ISNULL(@nodeDocumentUrlPath,'') != '') 
											THEN @parentDocumentUrlPath + '/' + RIGHT(@nodeDocumentUrlPath, CHARINDEX('/', REVERSE(@nodeDocumentUrlPath)) - 1) 
											ELSE @nodeDocumentUrlPath END;
			
				-- Generate aliases only for non-linked nodes on the current culture with DocumentURLPath specified
				IF (@newDocumentURLPath != @nodeDocumentUrlPath) AND (@nodeLinkedNodeId IS NULL) AND (ISNULL(@nodeDocumentUrlPath,'') != '') AND (ISNULL(@parentDocumentUrlPath,'') != '')
				BEGIN
					-- Check if same alias doesn't exist and doesn't exist document with same DocumentURLPath
					IF NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = @nodeDocumentUrlPath AND AliasNodeID = @nodeId AND (AliasCulture = @nodeDocumentCulture OR ISNULL(AliasCulture, '') = '')) AND
					NOT EXISTS (SELECT DocumentID FROM CMS_Document WHERE DocumentURLpath = @nodeDocumentUrlPath AND DocumentNodeID = @nodeId AND DocumentCulture = @nodeDocumentCulture)
					BEGIN
						INSERT INTO CMS_DocumentAlias (AliasNodeID, AliasCulture, AliasURLPath, AliasExtensions, AliasCampaign, AliasWildcardRule, AliasPriority, AliasGUID, AliasLastModified, AliasSiteID)
						VALUES (@nodeId, @nodeDocumentCulture, @nodeDocumentUrlPath, '', '', '', 1, NEWID(), GETDATE(), @SiteID);
					END
				END

				FETCH NEXT FROM @nodesCursor INTO @nodeId, @nodeDocumentCulture, @nodeDocumentURLPath, @nodeLinkedNodeId, @documentUseNamePathForUrlPath
			END

			CLOSE @nodesCursor;
			DEALLOCATE @nodesCursor;
		END
					
		FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	END
	
	CLOSE @parentCursor;
	DEALLOCATE @parentCursor;

	IF @updateChildren = 1
	BEGIN
		-- Go to next level
		SET @NodeLevel = @NodeLevel + 1;
		EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode, @GenerateAliases;															
	END
END
GO


-- HF-302 - Parameter 'TagGroupID' of TagSelector form control represented tag group ID which may not be preserved after import/export.
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 12
BEGIN
	DECLARE @formDefinition xml;

	-- Store current parameters definition of TagSelector form control
	SELECT @formDefinition = [UserControlParameters] FROM [CMS_FormUserControl] WHERE [UserControlCodeName] = N'tagselector';

	-- Correct TagGroupID field visibility
	SET @formDefinition.modify('replace value of (//field[@guid="ede16e44-5c08-4877-a19c-407062e93747"]/@publicfield)[1] with "false"');
	SET @formDefinition.modify('delete (//field[@guid="ede16e44-5c08-4877-a19c-407062e93747"]/@visible)[1]');

	-- Update parameters definition of TagSelector form control
	UPDATE [CMS_FormUserControl] SET [UserControlParameters] = CONVERT(nvarchar(max), @formDefinition) WHERE [UserControlCodeName] = N'tagselector';
END
GO


-- HF-320 - Add "Custom fields" tab to community groups
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 12
BEGIN
	DECLARE @resourceId INT;
	SET @resourceId = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE  [ResourceName] = 'CMS.Groups');
	IF NOT EXISTS (SELECT * FROM [CMS_UIElement] where [ElementGUID] = 'DF536424-1C20-4A5F-A9EF-C632F06F6336')
	BEGIN
		DECLARE @parentId INT;
		DECLARE @parentLevel INT;
		DECLARE @parentIdPath NVARCHAR(450); 
		SELECT TOP 1 @parentId = [ElementID], @parentIdPath = [ElementIDPath], @parentLevel = [ElementLevel] FROM [CMS_UIElement] where [ElementGUID] = '100B40E2-E0DE-4CDD-8D9A-B6AD3FACBB21';

		INSERT INTO [CMS_UIElement]
			([ElementDisplayName]
			,[ElementName]
			,[ElementTargetURL]
			,[ElementResourceID]
			,[ElementParentID]
			,[ElementChildCount]
			,[ElementOrder]
			,[ElementLevel]
			,[ElementIDPath]
			,[ElementIsCustom]
			,[ElementLastModified]
			,[ElementGUID]
			,[ElementSize]
			,[ElementFromVersion]
			,[ElementType]
			,[ElementIsMenu]
			,[ElementIsGlobalApplication]
			,[ElementCheckModuleReadPermission])
		 VALUES 
			(N'{$general.customfields$}',
			N'EditGroupCustomFields',
			N'~/CMSModules/Groups/Tools/Group_Edit_CustomFields.aspx?groupID={?objectid?}',
			@resourceId,
			@parentId,
			0,
			2,
			@parentLevel + 1,
			@parentIdPath,
			0,
			GETDATE(),
			'DF536424-1C20-4A5F-A9EF-C632F06F6336',
			0,
			N'8.0',
			N'Url',
			0,
			0,
			1);

		DECLARE @elementIdPath NVARCHAR(450); 
		DECLARE @elementId INT;
		SET @elementId = SCOPE_IDENTITY();
		SET @elementIdPath = (SELECT @parentIdPath + N'/' + (REPLICATE('0', 8 - LEN(@elementId)) + CONVERT(nvarchar(8), @elementId)));
	
		UPDATE [CMS_UIElement] SET [ElementIDPath] = @elementIdPath WHERE [ElementGUID] = 'DF536424-1C20-4A5F-A9EF-C632F06F6336';
		UPDATE [CMS_UIElement] SET [ElementProperties] = N'<data><displaytitleintabs>False</displaytitleintabs><objecttype>community.group</objecttype><includejquery>False</includejquery><displaybreadcrumbs>True</displaybreadcrumbs><addobjectidtobreadcrumbs>False</addobjectidtobreadcrumbs><rememberselectedtab>False</rememberselectedtab><allowsubtabs>True</allowsubtabs><tabextender>App_Code</tabextender><extenderclassname>GroupEditTabsExtender</extenderclassname><displaycategorybreadcrumb>False</displaycategorybreadcrumb><objectparameterid>groupId</objectparameterid></data>' WHERE [ElementGUID] = '100B40E2-E0DE-4CDD-8D9A-B6AD3FACBB21';
	END
END
GO


-- HF-322 - Language selection web part cache was not dependent on query string parameters
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 12
BEGIN
	-- Correct 'Language selection' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form version="2"><category name="Layout"><properties><visible>True</visible></properties></category><field column="DisplayLayout" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="50" publicfield="false" guid="df0b2382-6a9d-468f-a973-83c3c7f9c742" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Determines the orientation of the list of language selection links. Possible options are horizontal or vertical.</fielddescription><defaultvalue>horizontal</defaultvalue><fieldcaption>Display layout</fieldcaption></properties><settings><Options>&lt;item value="horizontal" text="Horizontal" /&gt;&lt;item value="vertical" text="Vertical" /&gt;</Options><controlname>dropdownlistcontrol</controlname></settings></field><field column="HideCurrentCulture" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="3c4acdf9-4ed6-4337-92aa-4a88aa238eaf" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates whether the link for the currently selected culture should be hidden.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide current culture</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="e1d55695-713e-4fa1-8f29-6d493c4515b2" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hideunavaliblecultures$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide unavailable cultures</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="76d686d3-d265-451b-b8d2-55fcc11fac3f" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.generateurlswithlangprefix$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Use culture specific URLs</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache"><properties><caption>Content cache</caption><visible>True</visible></properties></category><field column="CacheMinutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="0f070cff-ae4b-4879-a909-e286cfc7cede" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheminutes$}</fielddescription><fieldcaption>Cache minutes</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode></settings></field><field column="CacheByQueryStringParameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="c1c8873d-76d3-4dc2-a83f-9800ad7cf7cf" visibility="none" reftype="Required" resolvedefaultvalue="False"><properties><fielddescription>{$documentation.webpartproperties.cachebyqueryparameters$}</fielddescription><fieldcaption>Query string parameters</fieldcaption></properties><settings><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><controlname>TextBoxControl</controlname></settings></field></form>'
	WHERE [WebPartName] = 'languageselection';

	-- Correct 'Language selection drop-down' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form version="2"><category name="Layout"><properties><visible>True</visible></properties></category><field column="ShowCultureNames" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="92df5090-fcc6-4969-bb1e-bce506cf8714" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates if the names of the available cultures should be displayed. If disabled, only the flags matching the given cultures will be shown.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show culture names</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideCurrentCulture" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="37ef1dc3-1011-4ad1-b1f6-9034d8f866b4" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates whether the item representing the currently selected culture should be hidden.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide current culture</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideIfOneCulture" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" spellcheck="false" guid="7359b4dd-384b-4df8-b095-d9198ba483f9" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>If enabled, the drop-down list will be hidden if there is only one culture assigned to the site.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Hide if there is only one culture</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="17742874-d2d4-4d8f-97d6-08a9a8505c64" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates whether cultures that are not available for the current document should be hidden in the list.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide unavailable cultures</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="04eb4e84-4586-4d08-ad8b-0ef2392b4004" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.generateurlswithlangprefix$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Use culture specific URLs</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache"><properties><caption>Content cache</caption><visible>True</visible></properties></category><field column="CacheMinutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="097904ed-5a9f-4416-bac2-b5e691e458d6" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheminutes$}</fielddescription><fieldcaption>Cache minutes</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode></settings></field><field column="CacheByQueryStringParameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="166838c1-e7b2-45cf-b54b-4c51b4309bf3" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cachebyqueryparameters$}</fielddescription><fieldcaption>Query string parameters</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field></form>'
	WHERE [WebPartName] = 'languageselectiondropdown';

	-- Correct 'Language selection with flags' web part
	UPDATE [CMS_WebPart] SET [WebPartProperties] = '<form version="2"><category name="Layout"><properties><visible>True</visible></properties></category><field column="DisplayLayout" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="50" publicfield="false" guid="10e6554e-9af3-4a3c-b3d9-3145463335eb" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Determines the orientation of the list of language selection links. Possible options are horizontal or vertical.</fielddescription><defaultvalue>horizontal</defaultvalue><fieldcaption>Display layout</fieldcaption></properties><settings><Options>&lt;item value="horizontal" text="Horizontal" /&gt;&lt;item value="vertical" text="Vertical" /&gt;</Options><controlname>dropdownlistcontrol</controlname></settings></field><field column="ShowCultureNames" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="f062feda-7123-4045-a060-1244937dea41" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates if the names of the available cultures should be displayed. If disabled, only the flags matching the given cultures will be shown.</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Show culture names</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="Separator" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="24f9a476-9274-4a3f-8cb9-74a95e3b8934" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Defines the HTML code of the separator placed between individual culture links.</fielddescription><fieldcaption>Separator</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="HideCurrentCulture" visible="true" columntype="boolean" fieldtype="CustomUserControl" publicfield="false" guid="4d2b45a8-8a66-48b7-b289-ad27bf6b77a4" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>Indicates whether the link for the currently selected culture should be hidden.</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide current culture</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="HideUnavailableCultures" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="d1d3c436-dd6c-476f-b5a9-ff6e51203adb" visibility="none" translatefield="true" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.hideunavaliblecultures$}</fielddescription><defaultvalue>false</defaultvalue><fieldcaption>Hide unavailable cultures</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><field column="UseURLsWithLangPrefix" visible="true" columntype="boolean" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="d3711dd1-1d0b-4c09-a507-1a0fbcc16ede" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.generateurlswithlangprefix$}</fielddescription><defaultvalue>true</defaultvalue><fieldcaption>Use culture specific URLs</fieldcaption></properties><settings><controlname>checkboxcontrol</controlname></settings></field><category name="ContentCache"><properties><caption>Content cache</caption><visible>True</visible></properties></category><field column="CacheMinutes" visible="true" columntype="integer" fieldtype="CustomUserControl" allowempty="true" publicfield="false" guid="8bcaa87d-846d-4a76-ada1-408a187e9266" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cacheminutes$}</fielddescription><fieldcaption>Cache minutes</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="CacheByQueryStringParameters" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" columnsize="200" publicfield="false" guid="ff16a7fe-279c-4f3a-8df4-4063a160d6ac" visibility="none" reftype="Required"><properties><fielddescription>{$documentation.webpartproperties.cachebyqueryparameters$}</fielddescription><fieldcaption>Query string parameters</fieldcaption></properties><settings><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><controlname>textboxcontrol</controlname><FilterMode>False</FilterMode></settings></field></form>'
	WHERE [WebPartName] = 'languageselectionwithflags';
END
GO


-- HF-327 - Preview tab for document shows access denied even if user has full control via ACL permissions
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 12
BEGIN
	UPDATE CMS_UIElement SET ElementCheckModuleReadPermission = 0 WHERE ElementName = 'Preview' AND ElementResourceID = (SELECT ResourceID FROM CMS_Resource WHERE ResourceName = 'cms.content')
END
GO

-- HF-351 - Uniselectors listing showed "No data found" when more then 1000 items have been select
GO
ALTER FUNCTION [Func_Selection_ParseGUIDs]
(	
	@SelectionValues nvarchar(max)
)
RETURNS @List TABLE ( ItemGUID uniqueidentifier )
AS
BEGIN
	DECLARE @StartIndex int
	DECLARE @EndIndex int
	DECLARE @Value nvarchar(450)
	
	SET @StartIndex = 1
	SET @EndIndex = CHARINDEX(',', @SelectionValues)

	WHILE @EndIndex > 0
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, @EndIndex - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (@Value)
		END
		SET @StartIndex = @EndIndex + 1
		SET @EndIndex = CHARINDEX(',', @SelectionValues, @StartIndex)
	END
	
	IF LEN(@SelectionValues) >= @StartIndex
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, LEN(@SelectionValues) + 1 - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (@Value)
		END
	END
	
	RETURN
END
GO

ALTER FUNCTION [Func_Selection_ParseIDs]
(	
	@SelectionValues nvarchar(max)
)
RETURNS @List TABLE ( ItemID int )
AS
BEGIN
	DECLARE @StartIndex int
	DECLARE @EndIndex int
	DECLARE @Value nvarchar(450)
	DECLARE @Total int
	
	SET @StartIndex = 1
	SET @EndIndex = CHARINDEX(',', @SelectionValues)
	
	WHILE @EndIndex > 0
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, @EndIndex - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (CAST(@Value AS int))
		END
		SET @StartIndex = @EndIndex + 1
		SET @EndIndex = CHARINDEX(',', @SelectionValues, @StartIndex)
	END
	
	IF LEN(@SelectionValues) >= @StartIndex
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, LEN(@SelectionValues) + 1 - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (CAST(@Value AS int))
		END
	END
	
	RETURN
END
GO

ALTER FUNCTION [Func_Selection_ParseNames]
(	
	@SelectionValues nvarchar(max)
)
RETURNS @List TABLE ( ItemName nvarchar(450) )
AS
BEGIN
	DECLARE @StartIndex int
	DECLARE @EndIndex int
	DECLARE @Value nvarchar(450)
	
	SET @StartIndex = 1
	SET @EndIndex = CHARINDEX(',', @SelectionValues)
	
	WHILE @EndIndex > 0
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, @EndIndex - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (@Value)
		END
		SET @StartIndex = @EndIndex + 1
		SET @EndIndex = CHARINDEX(',', @SelectionValues, @StartIndex)
	END
	
	IF LEN(@SelectionValues) >= @StartIndex
	BEGIN
		SET @Value = LTRIM(RTRIM(SUBSTRING(@SelectionValues, @StartIndex, LEN(@SelectionValues) + 1 - @StartIndex)));
		IF @Value <> ''
		BEGIN
			INSERT INTO @List VALUES (@Value)
		END
	END
	
	RETURN
END
GO

-- HF-303 - Scoring did not allow to create state attribute rule
GO
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 14
BEGIN
	UPDATE [CMS_AlternativeForm] 
	SET [FormDefinition] = N'<form version="2"><field column="ContactID" visibility="none" visible="" /><field column="ContactFirstName"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname><AutoCompleteEnableCaching /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /></settings></field><field column="ContactMiddleName"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings></field><field column="ContactLastName"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname><AutoCompleteEnableCaching /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /></settings></field><field column="ContactSalutation"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactTitleBefore"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactTitleAfter"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactBirthday"><settings><controlname>datetimefilter</controlname><EditTime>False</EditTime></settings></field><field column="ContactGender"><settings><DisplayType>0</DisplayType><controlname>genderselector</controlname></settings></field><field column="ContactCompanyName"><settings><controlname>textfilter</controlname><AutoCompleteEnableCaching /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /></settings></field><field column="ContactJobTitle"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactCreated"><settings><controlname>datetimefilter</controlname></settings><properties><fieldcaption>{$om.contact.created$}</fieldcaption></properties></field><field column="ContactLastLogon"><settings><controlname>datetimefilter</controlname></settings><properties><fieldcaption>{$general.lastlogon$}</fieldcaption></properties></field><field column="ContactStatusID"><settings><DisplaySiteOrGlobal>True</DisplaySiteOrGlobal><controlname>contactstatusselector</controlname><AllowAllItem>False</AllowAllItem></settings><properties><fieldcaption>{$om.contactstatus$}</fieldcaption></properties></field><field column="ContactMonitored"><settings><controlname>booleanfilter</controlname></settings></field><field column="ContactOwnerUserID"><settings><controlname>userselector</controlname></settings></field><field column="ContactAddress1"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactAddress2"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactCity"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings><properties><fieldcaption>{$general.city$}</fieldcaption></properties></field><field column="ContactZIP"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings><properties><fieldcaption>{$general.zip$}</fieldcaption></properties></field><field column="ContactStateID" visible="true"><settings><ValuesSeparator>;</ValuesSeparator><AllowAll>False</AllowAll><EditDialogWindowHeight>700</EditDialogWindowHeight><controlname>Uni_selector</controlname><AddGlobalObjectNamePrefix>False</AddGlobalObjectNamePrefix><ReturnColumnName>StateID</ReturnColumnName><RemoveMultipleCommas>False</RemoveMultipleCommas><EditDialogWindowWidth>1000</EditDialogWindowWidth><AllowDefault>False</AllowDefault><DialogWindowName>SelectionDialog</DialogWindowName><MaxDisplayedItems>25</MaxDisplayedItems><ObjectType>cms.state</ObjectType><LocalizeItems>True</LocalizeItems><MaxDisplayedTotalItems>50</MaxDisplayedTotalItems><ItemsPerPage>25</ItemsPerPage><AddGlobalObjectSuffix>False</AddGlobalObjectSuffix><UseAutocomplete>False</UseAutocomplete><EncodeOutput>True</EncodeOutput><AllowEmpty>False</AllowEmpty><OrderBy>CountryID, StateName</OrderBy><EditWindowName>EditWindow</EditWindowName><AllowEditTextBox>False</AllowEditTextBox><SelectionMode>1</SelectionMode><GlobalObjectSuffix ismacro="True">{$general.global$}</GlobalObjectSuffix><ReturnColumnType>id</ReturnColumnType><AutoCompleteEnableCaching /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /></settings><properties><fieldcaption>{$general.state$}</fieldcaption></properties></field><field column="ContactCountryID"><settings><ReturnType>1</ReturnType><AddAllItemsRecord>False</AddAllItemsRecord><AddNoneRecord>False</AddNoneRecord><EnableStateSelection>False</EnableStateSelection><AddSelectCountryRecord>False</AddSelectCountryRecord><controlname>countrySelector</controlname><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><Trim /><AutoCompleteFirstRowSelected /><FilterMode /><AutoCompleteEnableCaching /></settings></field><field column="ContactMobilePhone"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactHomePhone"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactBusinessPhone"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings><properties><fieldcaption>{$om.contact.businessphone$}</fieldcaption></properties></field><field column="ContactEmail"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings><properties><fieldcaption>{$general.email$}</fieldcaption></properties></field><field column="ContactWebSite"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname></settings></field><field column="ContactNotes"><settings><ShowAnyValue>False</ShowAnyValue><controlname>textfilter</controlname><AutoCompleteEnableCaching /><AutoCompleteShowOnlyCurrentWordInCompletionListItem /><IsTextArea /><AutoCompleteFirstRowSelected /><FilterMode /></settings></field><field column="ContactMergedWithContactID"><settings><controlname>contactselector</controlname></settings><properties><fieldcaption>Merged into contact</fieldcaption></properties></field><field column="ContactIsAnonymous"><settings><controlname>booleanfilter</controlname></settings><properties><defaultvalue>false</defaultvalue><fieldcaption>{$om.contact.isanonymous$}</fieldcaption></properties></field><field column="ContactSiteID"><settings><controlname>selectsite</controlname></settings><properties><fieldcaption>Site</fieldcaption></properties></field><field column="ContactLastModified"><settings><TimeZoneType>inherit</TimeZoneType><controlname>datetimefilter</controlname></settings><properties><fieldcaption>{$general.lastmodified$}</fieldcaption></properties></field><field column="ContactMergedWhen" visible=""><settings><controlname>datetimefilter</controlname></settings><properties><fieldcaption>Merged when</fieldcaption></properties></field><field column="ContactGlobalContactID" visibility="none" /><field column="ContactBounces"><settings><controlname>numberfilter</controlname></settings><properties><fieldcaption>{$unigrid.newsletter_issue.columns.issuebounces$}</fieldcaption></properties></field></form>' 
	WHERE [FormName] = N'ScoringAttributeRule' AND [FormLastModified] = '2014-02-11 09:36:50.5951126';
END
GO


-- HF-359 - Replace wrong link to documentation in transformations with the right one
GO
UPDATE [CMS_Transformation] SET [TransformationCode] = REPLACE([TransformationCode], N'https://kentico.atlassian.net/wiki/x/QAQvAQ', N'https://docs.kentico.com/x/QAQvAQ') WHERE [TransformationName] = N'StrandsDefault' OR [TransformationName] = N'StrandsList'
GO

-- HF-399 - E-mail templates with macros within Subject field cannot be saved
-- UPDATE - The script is disabled because it caused an issue with some form definitions, see HF-493 for more details
/*DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 15
BEGIN
	DECLARE @startIndex INT
	DECLARE @endIndex INT
	DECLARE @xml NVARCHAR(max)
	DECLARE @oldRule NVARCHAR(max)
	DECLARE @newRule NVARCHAR(max)

	SELECT @xml = [ClassFormDefinition]	FROM [CMS_Class] WHERE [ClassName] = N'cms.emailtemplate'

	SET @startIndex = PATINDEX('%<rule>%', @xml)
	SET @endIndex = PATINDEX('%</rules>%', @xml)

	IF (@startIndex > 0 AND @endIndex > 0)
	BEGIN
		-- Get macro rule of EmailTemplateSubject field
		SET @oldRule = SUBSTRING(@xml, @startIndex, @endIndex - @startIndex)
		-- Remove signature
		SET @newRule = SUBSTRING(@oldRule, 0, PATINDEX('%|(user)administrator|(hash)________________________________________________________________%', @oldRule)) + '@%}</rule>'
		-- Replace rule parameters
		SET @newRule = REPLACE(@newRule, '150', '250')
		-- Replace rule in form definition
		SET @xml = REPLACE(@xml, @oldRule, @newRule)

		UPDATE [CMS_Class] SET [ClassFormDefinition] = @xml WHERE [ClassName] = N'cms.emailtemplate'
	END
END
GO*/


-- HF-442 - Renaming a document with large number of child documents could lead to timeout issue with 'Remember original URLs when moving pages' setting turned on. 
GO
ALTER PROCEDURE [Proc_CMS_Document_UpdateDocumentNamePath]
 @StartingAliasPath nvarchar(450),
 @NodeLevel int,
 @SiteID int,
 @DefaultCultureCode nvarchar(10),
 @GenerateAliases bit
AS
BEGIN
	DECLARE @nodeParentId int;
	DECLARE @parentDocumentCulture nvarchar(10);
	DECLARE @parentUseNamePathForUrlPath bit;
	DECLARE @parentDocumentUrlPath nvarchar(450);
	DECLARE @parentDocumentNamePath nvarchar(1500);
	DECLARE @documentUseNamePathForUrlPath bit;
	DECLARE @updatedChildren int;

	-- Cursor for all parent culture vesions in current level
	DECLARE @parentCursor CURSOR;

	-- Temp table for all parent culture vesions in current level
	DECLARE @parents TABLE (
		NodeParentID int,
		DocumentCulture nvarchar(10)
	);

	-- Get all parent culture versions in current level
	INSERT INTO @parents SELECT DISTINCT NodeParentID, DocumentCulture FROM View_CMS_Tree_Joined_Regular WHERE NodeAliasPath LIKE @StartingAliasPath + '/%' AND NodeLevel = @NodeLevel AND NodeSiteID = @SiteID

	-- Iterate through parent culture versions
	SET @parentCursor = CURSOR FOR SELECT NodeParentID, DocumentCulture FROM @parents;
	OPEN @parentCursor
	FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture

	-- There is parent document to process
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- Get best match (culture version) for parent document URL path and name path (including parent link documents)
		SELECT @parentDocumentNamePath = DocumentNamePath, @parentUseNamePathForUrlPath = DocumentUseNamePathForUrlPath, @parentDocumentUrlPath = DocumentUrlPath 
			FROM (SELECT TOP 1 DocumentNamePath, DocumentUseNamePathForUrlPath, DocumentUrlPath, ROW_NUMBER() OVER (PARTITION BY NodeID ORDER BY CASE WHEN DocumentCulture = @parentDocumentCulture THEN 1 WHEN DocumentCulture = @DefaultCultureCode THEN 2 ELSE 3 END) AS Priority
				FROM View_CMS_Tree_Joined 
					WHERE NodeID = @nodeParentId AND NodeAliasPath <> '/'
			ORDER BY Priority ASC) TopParentPath;

		-- Document aliases should be generated		
		IF (@GenerateAliases = 1)
		BEGIN
			-- Insert alias for all child documents where original URL path differs from the new one and the alias with same URL path doesn't exist
			INSERT INTO CMS_DocumentAlias (AliasNodeID, AliasCulture, AliasURLPath, AliasExtensions, AliasCampaign, AliasWildcardRule, AliasPriority, AliasGUID, AliasLastModified, AliasSiteID)
				SELECT NodeID AS AliasNodeID, DocumentCulture AS AliasCulture, DocumentURLPath AS AliasURLPath, '' AS AliasExtensions, '' AS AliasCampaign, '' AS AliasWildcardRule, 1 AS AliasPriority, NEWID() AS AliasGUID, GETDATE() AS AliasLastModified, @SiteID AS AliasSiteID
					FROM View_CMS_Tree_Joined 
						-- For all child documents in the same culture
						WHERE NodeParentID = @nodeParentId AND DocumentCulture = @parentDocumentCulture 
						-- URL path is used and differs from the original one
						AND DocumentUrlPath <> (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
						-- There is no alias with the same URL path
						AND NOT EXISTS (SELECT AliasID FROM CMS_DocumentAlias WHERE AliasURLPath = DocumentUrlPath AND AliasNodeID = NodeID AND (AliasCulture = DocumentCulture OR ISNULL(AliasCulture, '') = ''))
		END
				
		-- Update name path and URL path for all child documents in parent culture
		UPDATE CMS_Document SET 
			DocumentNamePath = @parentDocumentNamePath + '/' + DocumentName, 
			DocumentUrlPath = (CASE WHEN DocumentUseNamePathForUrlPath = 1 AND @parentUseNamePathForUrlPath = 1 AND (ISNULL(@parentDocumentUrlPath, '') <> '') AND  (ISNULL(DocumentUrlPath, '') <> '') THEN @parentDocumentUrlPath + '/' + RIGHT(DocumentUrlPath, CHARINDEX('/', REVERSE(DocumentUrlPath)) - 1) ELSE DocumentUrlPath END)
			-- In the same culture
			WHERE DocumentCulture = @parentDocumentCulture
			-- All child documents
			AND DocumentNodeID IN (SELECT NodeID FROM CMS_Tree WHERE NodeParentID = @nodeParentId) 
		
		-- Store number of updated child documents
		SET @updatedChildren = @@ROWCOUNT

		-- Get next parent
		FETCH NEXT FROM @parentCursor INTO @nodeParentId, @parentDocumentCulture
	END
	
	CLOSE @parentCursor;
	DEALLOCATE @parentCursor;
	-- All parents in level processed

	-- There are child documents to process
	IF @updatedChildren <> 0
	BEGIN
		-- Process next level
		SET @NodeLevel = @NodeLevel + 1;
		EXEC [Proc_CMS_Document_UpdateDocumentNamePath] @StartingAliasPath, @NodeLevel, @SiteID, @DefaultCultureCode, @GenerateAliases;															
	END
END
GO

-- HF-450 - MacroRules from version 7 missed default value of MacroRuleEnabled column after upgrade
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 18
BEGIN
	UPDATE [CMS_MacroRule] SET [MacroRuleEnabled] = 1 WHERE [MacroRuleEnabled] IS NULL
END
GO

-- HF-493 - Corrupted e-mail templates after hotfix
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 20
BEGIN

UPDATE [CMS_Class]
SET [ClassFormDefinition] = N'<form version="2"><field column="EmailTemplateID" columntype="integer" fieldtype="CustomUserControl" isPK="true" system="true" publicfield="false" guid="ada65d2f-9f6f-4cac-b7b4-380a13ba6a53" visibility="none" isunique="true" reftype="Required"><properties><fieldcaption>EmailTemplateID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="EmailTemplateDisplayName" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="200" publicfield="false" guid="4c80ea4a-4e2f-4f4e-b524-9ec6acb2290b" translatefield="true" reftype="Required"><properties><validationerrormessage>{$EmailTemplate_Edit.FillDisplayNameField$}</validationerrormessage><enabledmacro ismacro="true">{%QueryString[&quot;editonlycode&quot;] != &quot;1&quot; || FormMode == FormModeEnum.Insert@%}</enabledmacro><fieldcaption>{$general.displayname$}</fieldcaption></properties><settings><AutoCompleteShowOnlyCurrentWordInCompletionListItem>False</AutoCompleteShowOnlyCurrentWordInCompletionListItem><Trim>False</Trim><AutoCompleteFirstRowSelected>False</AutoCompleteFirstRowSelected><FilterMode>False</FilterMode><controlname>textboxcontrol</controlname><AutoCompleteEnableCaching>False</AutoCompleteEnableCaching></settings></field><field column="EmailTemplateName" visible="true" columntype="text" fieldtype="CustomUserControl" system="true" columnsize="200" publicfield="false" spellcheck="false" guid="db77f0cf-12cf-43e6-be0a-28c1c97fb026" reftype="Required"><properties><validationerrormessage>{$EmailTemplate_Edit.FillCodeNameField$}</validationerrormessage><enabledmacro ismacro="true">{%QueryString[&quot;editonlycode&quot;] != &quot;1&quot; || FormMode == FormModeEnum.Insert@%}</enabledmacro><fieldcaption>{$general.codename$}</fieldcaption></properties><settings><controlname>codename</controlname></settings></field><field column="EmailTemplateType" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="100" publicfield="false" spellcheck="false" guid="3c94ab49-0c7e-4546-9528-a2ded8babc29" hasdependingfields="true" reftype="Required"><properties><defaultvalue ismacro="true">{?templatetype?}</defaultvalue><enabledmacro ismacro="true">{%QueryString[&quot;editonlycode&quot;] != &quot;1&quot;@%}</enabledmacro><fieldcaption>{$emailtemplate_edit.emailtype$}</fieldcaption></properties><settings><Sort>True</Sort><UseStringRepresentation>True</UseStringRepresentation><AssemblyName>CMS.EmailEngine</AssemblyName><ResourcePrefix>emailtemplate.type</ResourcePrefix><DisplayType>0</DisplayType><controlname>email_template_type_selector</controlname></settings></field><field column="EmailTemplateFrom" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="250" publicfield="false" spellcheck="false" guid="515d919e-b186-4bc4-9064-c086fd34715c" reftype="Required"><properties><fieldcaption>{$general.fromemail$}</fieldcaption></properties><settings><AllowMultipleAddresses>True</AllowMultipleAddresses><controlname>emailinput</controlname><EmailSeparator>;</EmailSeparator></settings></field><field column="EmailTemplateCc" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="4000" publicfield="false" spellcheck="false" guid="43b52be1-a0d2-4af5-9ae4-5e80ca589396" reftype="Required"><properties><fieldcaption>{$dialogs.email.cc$}</fieldcaption></properties><settings><AllowMultipleAddresses>True</AllowMultipleAddresses><controlname>emailinput</controlname><EmailSeparator>;</EmailSeparator></settings></field><field column="EmailTemplateBcc" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="4000" publicfield="false" spellcheck="false" guid="f0fafbef-3dd5-40d8-923c-091f692e7664" reftype="Required"><properties><fieldcaption>{$emailtemplate_edit.bcc$}</fieldcaption></properties><settings><AllowMultipleAddresses>True</AllowMultipleAddresses><controlname>emailinput</controlname><EmailSeparator>;</EmailSeparator></settings></field><category name="Subject"><properties><caption>{$general.subject$}</caption><visible>true</visible></properties></category><field column="EmailTemplateSubject" visible="true" columntype="text" fieldtype="CustomUserControl" allowempty="true" system="true" columnsize="250" publicfield="false" guid="31f6996b-5f0e-4350-bfb7-4857e4b89bb0" reftype="Required"><properties><fieldcaption>{$general.subject$}</fieldcaption></properties><settings><ShowBookmarks>False</ShowBookmarks><SupportPasteImages>False</SupportPasteImages><AutoSize>False</AutoSize><ShowLineNumbers>False</ShowLineNumbers><Language>7</Language><EnablePositionMember>False</EnablePositionMember><Height>100</Height><ShowMacroSelector>False</ShowMacroSelector><SingleLineMode>True</SingleLineMode><SingleMacroMode>False</SingleMacroMode><EnableViewState>False</EnableViewState><Width>100</Width><controlname>macroeditor</controlname><EnableSections>False</EnableSections></settings><rules><rule>{%Rule(&quot;Value.Length &lt;= 250&quot;, &quot;&lt;rules&gt;&lt;r pos=\&quot;0\&quot; par=\&quot;\&quot; op=\&quot;and\&quot; n=\&quot;MaxLength\&quot; &gt;&lt;p n=\&quot;maxlength\&quot;&gt;&lt;t&gt;250&lt;/t&gt;&lt;v&gt;250&lt;/v&gt;&lt;r&gt;0&lt;/r&gt;&lt;d&gt;&lt;/d&gt;&lt;vt&gt;integer&lt;/vt&gt;&lt;tv&gt;0&lt;/tv&gt;&lt;/p&gt;&lt;/r&gt;&lt;/rules&gt;&quot;)@%}</rule></rules></field><category name="HTMLLayout"><properties><caption>{$emailtemplate_edit.htmlversion$}</caption><visible>true</visible></properties></category><field column="EmailTemplateText" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="7cb8a717-2b0c-4b92-9e38-2530185dcafb" dependsonanotherfield="true" translatefield="true" reftype="Required"><properties><controlcellcssclass>textarea-full-width editing-form-value-cell</controlcellcssclass><captioncellcssclass>sr-only</captioncellcssclass><fieldcaption>{$emailtemplate_edit.htmlversion$}</fieldcaption></properties><settings><EnableSections>False</EnableSections><controlname>macroeditor</controlname><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><AutoSize>False</AutoSize><Height>400px</Height><SupportPasteImages>True</SupportPasteImages><EditorMode>1</EditorMode><EnableViewState>False</EnableViewState><SingleLineMode>False</SingleLineMode><EnablePositionMember>False</EnablePositionMember><ShowMacroSelector>False</ShowMacroSelector><SingleMacroMode>False</SingleMacroMode><Language>7</Language><Width>100%</Width></settings></field><category name="PlainText"><properties><caption>{$emailtemplate_edit.plaintextversion$}</caption><visible>true</visible></properties></category><field column="EmailTemplatePlainText" visible="true" columntype="longtext" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="6c25debb-1332-41eb-a77c-a69f93b3111c" dependsonanotherfield="true" reftype="Required"><properties><controlcellcssclass>textarea-full-width editing-form-value-cell</controlcellcssclass><captioncellcssclass>sr-only</captioncellcssclass><fieldcaption>{$emailtemplate_edit.plaintextversion$}</fieldcaption></properties><settings><EnableSections>False</EnableSections><controlname>macroeditor</controlname><ShowBookmarks>False</ShowBookmarks><ShowLineNumbers>False</ShowLineNumbers><AutoSize>False</AutoSize><Height>400px</Height><SupportPasteImages>False</SupportPasteImages><EditorMode>1</EditorMode><EnableViewState>False</EnableViewState><SingleLineMode>False</SingleLineMode><EnablePositionMember>False</EnablePositionMember><ShowMacroSelector>False</ShowMacroSelector><SingleMacroMode>False</SingleMacroMode><Language>0</Language><Width>100%</Width></settings></field><field column="EmailTemplateSiteID" columntype="integer" fieldtype="CustomUserControl" allowempty="true" system="true" publicfield="false" guid="152ad89f-51ae-42f3-a7cd-b28794ebbb73" reftype="Required"><properties><fieldcaption>Site</fieldcaption></properties><settings><OnlySpecialFields>False</OnlySpecialFields><AllowGlobal>False</AllowGlobal><controlname>selectsite</controlname><AllowAll>False</AllowAll><AllowEmpty>True</AllowEmpty></settings></field><field column="EmailTemplateGUID" columntype="guid" fieldtype="CustomUserControl" system="true" publicfield="false" guid="42373ea6-c944-44c2-9a3f-95c5bdc78012" visibility="none" reftype="Required"><properties><fieldcaption>EmailTemplateGUID</fieldcaption></properties><settings><controlname>labelcontrol</controlname></settings></field><field column="EmailTemplateLastModified" columntype="datetime" fieldtype="CustomUserControl" system="true" publicfield="false" guid="513a454c-2061-4083-88bb-12b92bdf2a5e" visibility="none" reftype="Required"><properties><fieldcaption>EmailTemplateLastModified</fieldcaption></properties><settings><controlname>calendarcontrol</controlname></settings></field></form>'
WHERE [ClassName] = N'cms.emailtemplate'

END
GO


-- HF-518 - Corrupted UI Elements after staging
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 21
BEGIN

UPDATE [CMS_UIElement] SET [ElementType] = N'PageTemplate' WHERE [ElementType] = N'Url' AND [ElementPageTemplateID] > 0 AND ISNULL([ElementTargetURL], '') = ''
UPDATE [CMS_UIElement] SET [ElementType] = N'Url' WHERE [ElementType] = N'0'
UPDATE [CMS_UIElement] SET [ElementType] = N'PageTemplate' WHERE [ElementType] = N'1'
UPDATE [CMS_UIElement] SET [ElementType] = N'UserControl' WHERE [ElementType] = N'2'
UPDATE [CMS_UIElement] SET [ElementType] = N'Javascript' WHERE [ElementType] = N'3'
UPDATE [CMS_UIElement] SET [ElementType] = N'Url' WHERE ISNULL([ElementType], '') = '' AND ISNULL([ElementTargetURL], '') != ''

END
GO



-- Do not change code below this line
GO
-- End of file
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '22' WHERE KeyName = N'CMSHotfixVersion'
GO
