﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CMS.Controls
{
    /// <summary>
    /// Base class for transformation methods
    /// </summary>
    public partial class CMSTransformation : CMSAbstractTransformation
    {
    }
}
