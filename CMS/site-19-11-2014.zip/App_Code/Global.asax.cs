using System.Web;
using System;

/// <summary>
/// Application methods.
/// </summary>
public class Global : CMSHttpApplication
{
    #region "System data (do not modify)"

    /// <summary>
    /// Application version, do not change.
    /// </summary>
    /// const string APP_VERSION = "7.0";

    #endregion
}