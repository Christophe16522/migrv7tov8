﻿var SHLanguage =
{
    ToggleLineNumbers   : "Zobraziť/skryť čísla riadkov",
    FitWindow           : "Prepnúť zobrazenie na veľkosť okna",
	Undo                : "Späť",
	Redo                : "Znovu",
	Search              : "Hľadať",
	Replace             : "Nahradiť",
	EditSource          : "Upraviť zdroj",
	IndentAll           : "Odsadiť všetko",
	TextNotFound        : "Nasledujúcí hľadaný text nebol nájdený",
	XOccurencesReplaced : "výskytov hľadaného textu bolo nájdených a nahradených"
};