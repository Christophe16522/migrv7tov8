﻿var SHLanguage =
{
    ToggleLineNumbers   : "Show/hide line numbers",
    FitWindow           : "Toggle fit-to-window mode",
    ToggleBookmarks     : "Show/hide bookmarks",
    Undo                : "Undo",
	Redo                : "Redo",
	Search              : "Search",
	Replace             : "Replace",
	EditSource          : "Edit source",
	AutoFormat          : "Indent all",
	TextNotFound        : "The following specified text was not found, moving cursor back to the start of the editor ...",
	XOccurencesReplaced : "occurences of specified text were found and replaced"
};