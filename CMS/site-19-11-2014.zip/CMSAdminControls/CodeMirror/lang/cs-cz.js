﻿var SHLanguage =
{
    ToggleLineNumbers   : "Zobrazit/skrýt čísla řádků",
    FitWindow           : "Přepnout zobrazení na velikost okna",
    ToggleBookmarks     : "Zobrazit/skrýt záložky",
    Undo                : "Zpět",
	Redo                : "Znovu",
	Search              : "Hledat",
	Replace             : "Nahradit",
	EditSource          : "Upravit zdroj",
	AutoFormat          : "Odsadit vše",
	TextNotFound        : "Následující hledaný text nebyl nalezen",
	XOccurencesReplaced : "výskytů hledaného textu bylo nalezených a nahrazených"
};