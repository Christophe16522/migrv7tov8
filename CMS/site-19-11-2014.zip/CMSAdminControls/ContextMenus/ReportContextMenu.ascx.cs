﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using CMS.ExtendedControls;
using CMS.GlobalHelper;
using CMS.SettingsProvider;

public partial class CMSAdminControls_ContextMenus_ReportContextMenu : CMSContextMenuControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        bool enableExport = ContextMenu.Parameter.Contains("enableexport");
        bool enableSubscription = ContextMenu.Parameter.Contains("enablesubscription");
        string[] arr = ContextMenu.Parameter.Trim('\'').Split(';');
        if (arr.Length > 0)
        {
            switch (arr[0].ToLowerCSafe())
            {
                case "graph":
                    lblSubscription.ResourceString = "reportsubscription.graph";
                    break;

                case "table":
                    lblSubscription.ResourceString = "reportsubscription.table";
                    break;

                case "value":
                    lblSubscription.ResourceString = "reportsubscription.value";
                    break;

                case "htmlgraph":
                    lblSubscription.ResourceString = "reportsubscription.htmlgraph";
                    break;
            }
        }

        string menuId = ContextMenu.MenuID;

        string parentElemId = ContextMenu.ParentElementClientID;
        pnlExport.Visible = enableExport;
        pnlSubscription.Visible = enableSubscription;

        string parameterScript = "GetContextMenuParameter('" + menuId + "')";
        string hideProgress = "if(window.HideIndicator) {HideIndicator(false); CM_Close('" + menuId + "', 0); }";
        string actionPattern = "Report_ContextMenu_" + parentElemId + "('{0}', " + parameterScript + ");HideContextMenu('" + menuId + "', true);";

        // Initialize menu
        imgExcel.ImageUrl = UIHelper.GetImageUrl(Page, "Design/Controls/UniGrid/Actions/excelexport.png");
        lblExcel.Text = imgExcel.AlternateText = ResHelper.GetString("export.exporttoexcel");
        pnlExcel.Attributes.Add("onclick", string.Format(actionPattern, DataExportFormatEnum.XLSX) + hideProgress);

        imgCSV.ImageUrl = UIHelper.GetImageUrl(Page, "Design/Controls/UniGrid/Actions/csvexport.png");
        lblCSV.Text = imgCSV.AlternateText = ResHelper.GetString("export.exporttocsv");
        pnlCSV.Attributes.Add("onclick", string.Format(actionPattern, DataExportFormatEnum.CSV) + hideProgress);

        imgXML.ImageUrl = UIHelper.GetImageUrl(Page, "Design/Controls/UniGrid/Actions/xmlexport.png");
        lblXML.Text = imgXML.AlternateText = ResHelper.GetString("export.exporttoxml");
        pnlXML.Attributes.Add("onclick", string.Format(actionPattern, DataExportFormatEnum.XML) + hideProgress);

        imgSubscription.ImageUrl = UIHelper.GetImageUrl(Page, "CMSModules/CMS_Reporting/Subscription.png");
        imgSubscription.AlternateText = GetString("newslettertemplate_list.subscription");
        pnlSubscription.Attributes.Add("onclick", string.Format(actionPattern, "subscription") + hideProgress);
    }
}