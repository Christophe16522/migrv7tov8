using System;
using System.Web.UI;

using CMS.CMSHelper;
using CMS.ExtendedControls;
using CMS.GlobalHelper;
using CMS.PortalEngine;
using CMS.SettingsProvider;
using CMS.SiteProvider;
using CMS.DocumentEngine;
using CMS.UIControls;
using CMS.WebAnalytics;
using CMS.EventLog;

public partial class CMSAdminControls_ContentRating_RatingControl : CMSUserControl
{
    #region "Private variables"

    private AbstractRatingControl usrControl = null;
    private int mMaxRatingValue = 5;
    private double mExternalValue = -1.0;
    private string mRatingType = "Stars";
    private bool mShowResultMessage = false;
    private string mResultMessage = null;
    private string mErrorMessage = null;
    private string mMessageAfterRating = null;
    private bool mAllowForPublic = true;
    private bool mCheckIfUserRated = true;
    private bool mHideToUnauthorized = false;
    private bool mCheckPermissions = true;
    private bool mAllowZeroValue = true;
    private bool mEnabled = true;
    private bool loaded = false;

    #endregion


    #region "Public properties"

    /// <summary>
    /// Gets or sets max value of scale.
    /// </summary>
    public int MaxRatingValue
    {
        get
        {
            return mMaxRatingValue;
        }
        set
        {
            mMaxRatingValue = value;
        }
    }


    /// <summary>
    /// Gets or sets value that indicates whether unrated value is allowed.
    /// </summary>
    public bool AllowZeroValue
    {
        get
        {
            return mAllowZeroValue;
        }
        set
        {
            mAllowZeroValue = value;
        }
    }


    /// <summary>
    /// Gets or sets current value. If value is negative number then document
    /// rating is used.
    /// </summary>
    public string ExternalValue
    {
        get
        {
            return mExternalValue.ToString();
        }
        set
        {
            double extValue = ValidationHelper.GetDouble(value, -1.0);
            if (mExternalValue != extValue)
            {
                // Set external value and reload control
                mExternalValue = extValue;

                if (loaded)
                {
                    // Reload data
                    ReloadData(true);
                }
            }
        }
    }


    /// <summary>
    /// Code name of form control that manages rating scale.
    /// </summary>
    public string RatingType
    {
        get
        {
            return mRatingType;
        }
        set
        {
            mRatingType = value;
        }
    }


    /// <summary>
    /// If true the brief result info is shown.
    /// </summary>
    public bool ShowResultMessage
    {
        get
        {
            return mShowResultMessage;
        }
        set
        {
            mShowResultMessage = value;
        }
    }


    /// <summary>
    /// Gets or sets result info message that is displayed after rating.
    /// </summary>
    public string ResultMessage
    {
        get
        {
            return mResultMessage;
        }
        set
        {
            mResultMessage = value;
        }
    }


    /// <summary>
    /// Gets or sets message that is displayed after rating.
    /// </summary>
    public string MessageAfterRating
    {
        get
        {
            return mMessageAfterRating;
        }
        set
        {
            mMessageAfterRating = value;
        }
    }


    /// <summary>
    /// Gets or sets message that is displayed when user forgot to rate.
    /// </summary>
    public string ErrorMessage
    {
        get
        {
            return mErrorMessage;
        }
        set
        {
            mErrorMessage = value;
        }
    }


    /// <summary>
    /// Gets or sets value that indicates whether rating is allowed for public users.
    /// </summary>
    public bool AllowForPublic
    {
        get
        {
            return mAllowForPublic;
        }
        set
        {
            mAllowForPublic = value;
        }
    }


    /// <summary>
    /// Enables/disables checking if user voted.
    /// </summary>
    public bool CheckIfUserRated
    {
        get
        {
            return mCheckIfUserRated;
        }
        set
        {
            mCheckIfUserRated = value;
        }
    }


    /// <summary>
    /// If true, the control hides when user is not authorized.
    /// </summary>
    public bool HideToUnauthorizedUsers
    {
        get
        {
            return mHideToUnauthorized;
        }
        set
        {
            mHideToUnauthorized = value;
        }
    }


    /// <summary>
    /// Gets or sets the value that indicates whether permissions are checked.
    /// </summary>
    public bool CheckPermissions
    {
        get
        {
            return mCheckPermissions;
        }
        set
        {
            mCheckPermissions = value;
        }
    }


    /// <summary>
    /// Enables/disables rating control 
    /// </summary>
    public bool Enabled
    {
        get
        {
            return mEnabled;
        }
        set
        {
            mEnabled = value;
        }
    }

    #endregion


    #region "Methods"

    protected void Page_Load(object sender, EventArgs e)
    {
        ReloadData(false);
    }


    /// <summary>
    /// Occures on rating event.
    /// </summary>
    protected void usrControl_RatingEvent(AbstractRatingControl sender)
    {
        // Check if control is enabled
        if (!(Enabled && HasPermissions() && !(CheckIfUserRated && TreeProvider.HasRated(CMSContext.CurrentDocument))))
        {
            return;
        }

        // Check banned ip
        if (!BannedIPInfoProvider.IsAllowed(CMSContext.CurrentSiteName, BanControlEnum.AllNonComplete))
        {
            pnlError.Visible = true;
            lblError.Text = GetString("general.bannedip");
            return;
        }

        // Check null value
        if (!AllowZeroValue && usrControl.CurrentRating <= 0)
        {
            pnlError.Visible = true;
            lblError.Text = ErrorMessage;
            return;
        }

        if (CMSContext.CurrentDocument != null)
        {
            // Check whether user has already rated
            if (CheckIfUserRated && TreeProvider.HasRated(CMSContext.CurrentDocument))
            {
                return;
            }

            // Update document rating, remember rating in cookie if required
            TreeProvider.AddRating(CMSContext.CurrentDocument, usrControl.CurrentRating, CheckIfUserRated);

            // log activity
            LogActivity(usrControl.CurrentRating);

            // Get absolute rating value of the current rating
            double currRating = usrControl.MaxRating * usrControl.CurrentRating;
            // Reload rating control
            ReloadData(true);
            // Show message after rating if enabled or set
            if (!string.IsNullOrEmpty(MessageAfterRating))
            {
                pnlMessage.Visible = true;
                // Merge message text with rating values
                lblMessage.Text = String.Format(MessageAfterRating,
                                                Convert.ToInt32(currRating), usrControl.CurrentRating * usrControl.MaxRating, CMSContext.CurrentDocument.DocumentRatings);
            }
            else
            {
                pnlMessage.Visible = false;
            }
        }
    }


    /// <summary>
    /// Reload all values.
    /// </summary>
    public void ReloadData()
    {
        ReloadData(false);
    }


    /// <summary>
    /// Reload all values.
    /// </summary>
    /// <param name="forceReload">Forces reload</param>
    public void ReloadData(bool forceReload)
    {
        if (StopProcessing || (loaded && !forceReload))
        {
            return;
        }

        // Check permissions
        if (HideToUnauthorizedUsers && !HasPermissions())
        {
            Visible = false;
            return;
        }

        if (CMSContext.CurrentDocument != null)
        {
            try
            {
                // Insert rating control to page
                usrControl = (AbstractRatingControl)(Page.LoadUserControl(AbstractRatingControl.GetRatingControlUrl(RatingType + ".ascx")));
            }
            catch (Exception e)
            {
                Controls.Add(new LiteralControl(e.Message));
                return;
            }

            double rating = 0.0f;

            // Use current document rating if external value is not used
            if (mExternalValue < 0)
            {
                if (CMSContext.CurrentDocument.DocumentRatings > 0)
                {
                    rating = CMSContext.CurrentDocument.DocumentRatingValue / CMSContext.CurrentDocument.DocumentRatings;
                }
            }
            else
            {
                rating = mExternalValue;
            }

            // Check allowed interval 0.0-1.0
            if ((rating < 0.0) || (rating > 1.0))
            {
                rating = 0.0;
            }

            // Init values
            usrControl.ID = "RatingControl";
            usrControl.MaxRating = MaxRatingValue;
            usrControl.CurrentRating = rating;
            usrControl.Visible = true;
            usrControl.Enabled = Enabled && HasPermissions() && !(CheckIfUserRated && TreeProvider.HasRated(CMSContext.CurrentDocument));

            RefreshResultMessage();

            usrControl.RatingEvent += new AbstractRatingControl.OnRatingEventHandler(usrControl_RatingEvent);
            pnlRating.Controls.Clear();
            pnlRating.Controls.Add(usrControl);

            // Set 'loaded' flag
            loaded = true;
        }
    }


    /// <summary>
    /// Refreshes result info message.
    /// </summary>
    private void RefreshResultMessage()
    {
        if (ShowResultMessage && (!string.IsNullOrEmpty(ResultMessage)))
        {
            pnlResult.Visible = true;
            try
            {
                // Merge result text with rating values
                lblResult.Text = String.Format(ResultMessage, usrControl.CurrentRating * usrControl.MaxRating, CMSContext.CurrentDocument.DocumentRatings);
            }
            catch (Exception ex)
            {
                EventLogProvider.LogException("Rating control", "SHOWRESULT", ex);
                pnlResult.Visible = false;
            }
        }
        else
        {
            pnlResult.Visible = false;
        }
    }


    /// <summary>
    /// Returns true if user has permissions to access to the rating control.
    /// </summary>
    private bool HasPermissions()
    {
        if (!CheckPermissions || CMSContext.CurrentUser.IsGlobalAdministrator)
        {
            return true;
        }

        if (AllowForPublic && CMSContext.CurrentUser.IsPublic())
        {
            return true;
        }

        if (!CMSContext.CurrentUser.IsPublic())
        {
            return true;
        }

        return false;
    }


    /// <summary>
    /// Logs rating activity
    /// </summary>
    /// <param name="value">Rating value</param>
    private void LogActivity(double value)
    {
        TreeNode currentDoc = CMSContext.CurrentDocument;
        if (currentDoc != null)
        {
            string title = String.Format("{0} ({1})", value.ToString(), currentDoc.GetDocumentName());
            Activity activity = new ActivityRating(title, value, currentDoc, CMSContext.ActivityEnvironmentVariables);
            activity.Log();
        }
    }

    #endregion
}